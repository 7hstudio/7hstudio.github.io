Config = {}

-- =========================================================================
-- ⚡ 7H BEATSTORM 3D • MASTER CONFIGURATION
-- =========================================================================

-- Framework Detection ('auto', 'qb-core', 'qbx_core')
Config.Framework = 'auto'

-- Target System Detection ('auto', 'ox_target', 'qb-target')
Config.TargetSystem = 'auto'

-- Inventory System ('auto', 'ox_inventory', 'qb-inventory', 'qs-inventory')
Config.Inventory = 'auto'

-- Default Locale ('en' or 'fr')
Config.Locale = 'fr'

-- =========================================================================
-- 🔊 3D SPATIAL AUDIO & ACOUSTICS ENGINE
-- =========================================================================
Config.Audio = {
    -- Base audible distance in meters
    DefaultDistance = 28.0,
    -- Expanded audible distance when "MEGABASS" mode is toggled ON
    MegaBassDistance = 48.0,
    -- Default volume when starting a track (0.05 to 1.0)
    DefaultVolume = 0.65,
    -- Dynamic Wall Occlusion: muffles sound when blocked by walls/doors
    WallOcclusion = true,
    -- Lowpass filter frequency when occluded by concrete/walls (Hz)
    OcclusionCutoff = 380,
    -- Refresh interval for spatial orientation and distance matrix (ms)
    SpatialSyncInterval = 80,
    -- Camera bass-drop shake effect when a heavy 808 sub drops
    BassDropCamShake = true,
    -- Intensity of screen vibration on heavy bass (0.05 to 1.0)
    BassDropIntensity = 0.22,
    -- Max simultaneous boomboxes active in the same streaming zone
    MaxConcurrentAudio = 8
}

-- =========================================================================
-- 🔋 BATTERY & POWER MANAGEMENT
-- =========================================================================
Config.Battery = {
    Enabled = true,
    -- Seconds per 1% battery drain at 50% volume
    BaseDrainInterval = 35,
    -- Multiplier when volume is > 85% or MegaBass is ON
    HighVolumeDrainMultiplier = 1.6,
    -- Item name for recharging the boombox in the field
    RechargeItem = 'powerbank',
    -- Percentage restored per powerbank use
    RechargeAmount = 50,
    -- Seconds to recharge with powerbank
    RechargeTime = 5000,
    -- Auto-charge when docked in a running vehicle trunk
    VehicleCharging = true,
    -- Warn player with audio cue when battery reaches this threshold (%)
    LowBatteryWarning = 15
}

-- =========================================================================
-- 📼 PHYSICAL MIXTAPE / CASSETTE SYSTEM
-- =========================================================================
Config.Mixtapes = {
    Enabled = true,
    -- Blank tape item name
    BlankTapeItem = 'blank_cassette',
    -- Burned/recorded tape item name
    MixtapeItem = 'boombox_tape',
    -- Allowed audio sources for recording
    AllowedSources = {
        youtube = true,
        soundcloud = true,
        direct_mp3 = true,
        stream_url = true
    },
    -- Max custom title character length
    MaxLabelLength = 32
}

-- =========================================================================
-- 🚗 VEHICLE TRUNK DOCK ("PARTY TRUNK MODE")
-- =========================================================================
Config.VehicleTrunk = {
    Enabled = true,
    -- Auto-sync vehicle neon and brake lights with the bass beat
    SyncLightsWithBass = true,
    -- Allowed vehicle classes for trunk docking
    -- 0: Compacts, 1: Sedans, 2: SUVs, 3: Coupes, 4: Muscle, 5: Sports Classics,
    -- 6: Sports, 7: Super, 8: Motorcycles (No), 9: Off-road, 12: Vans
    AllowedClasses = { 0, 1, 2, 3, 4, 5, 6, 7, 9, 12 },
    -- Bone preference for mounting
    TrunkBones = { 'boot', 'trunk', 'engine' },
    -- Fallback offset if trunk bone is not standard
    DefaultMountOffset = vector3(0.0, -1.8, 0.45),
    DefaultMountRot = vector3(0.0, 0.0, 180.0)
}

-- =========================================================================
-- 🎒 PHYSICALITY & CARRIED STYLES
-- =========================================================================
Config.Props = {
    -- Default boombox prop model
    DefaultModel = `prop_boombox_01`,
    -- Secondary retro tape recorder prop model
    RetroModel = `prop_tapeplayer_01`,
    -- Shoulder Carry Animation & Bone Offsets
    ShoulderCarry = {
        animDict = 'anim@heists@box_carry@',
        animClip = 'idle',
        bone = 24818, -- SKEL_Spine3 / Right Clavicle
        offset = vector3(0.18, 0.12, 0.38),
        rotation = vector3(0.0, 85.0, 95.0)
    },
    -- Hand / Luggage Carry Offsets
    HandCarry = {
        animDict = 'amb@world_human_muscle_weights@male@idle_a',
        animClip = 'idle_a',
        bone = 57005, -- SKEL_R_Hand
        offset = vector3(0.15, 0.0, -0.05),
        rotation = vector3(0.0, 90.0, 0.0)
    }
}

-- =========================================================================
-- 📻 BUILT-IN FM RADIO STATIONS & CURATED PRESETS
-- =========================================================================
Config.FMPresets = {
    {
        name = 'Moroccan Vibes (Chaabi & Rai)',
        genre = 'MAGHREB • RAI',
        streamUrl = 'https://stream.zeno.fm/f0r1vv42q8quv',
        icon = 'cassette-tape'
    },
    {
        name = 'Cyberpunk 2077 Night FM',
        genre = 'SYNTHWAVE • DARK ELECTRO',
        streamUrl = 'https://stream.zeno.fm/0r0xa792kwzuv',
        icon = 'radio'
    },
    {
        name = 'Lofi Girl Hip-Hop Beats',
        genre = 'LO-FI • CHILL STUDY',
        streamUrl = 'https://stream.zeno.fm/f3wvbbqmdg8uv',
        icon = 'headphones'
    },
    {
        name = 'French Rap & Drill 24/7',
        genre = 'DRILL • URBAN',
        streamUrl = 'https://stream.zeno.fm/u8e3b2e3kzzuv',
        icon = 'fire'
    },
    {
        name = 'Classic 90s West Coast Hip Hop',
        genre = 'OLD SCHOOL • BOOM BAP',
        streamUrl = 'https://stream.zeno.fm/yn9um2ug7k8uv',
        icon = 'disc'
    }
}

-- =========================================================================
-- 🌈 RGB LED AURA & LIGHT EMISSION
-- =========================================================================
Config.RGBLights = {
    Enabled = true,
    -- Light emission radius in meters
    Radius = 4.5,
    -- Light brightness intensity
    Intensity = 2.2,
    -- Default pulse mode ('beat', 'rainbow', 'static', 'off')
    DefaultMode = 'beat'
}
