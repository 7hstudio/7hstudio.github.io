-- =========================================================================
-- 📼 7H BEATSTORM 3D • USABLE ITEMS & MIXTAPE BURNING
-- =========================================================================

-- Register Usable Item Helper (QBCore / QBX / OX)
local function RegisterItem(itemName, callback)
    if Bridge.Framework == 'qb-core' or Bridge.Framework == 'qbx_core' then
        local QBCore = exports['qb-core']:GetCoreObject()
        if QBCore then
            QBCore.Functions.CreateUseableItem(itemName, function(source, item)
                callback(source, item)
            end)
        end
    end
end

-- 1. Usable Item: BOOMBOX
RegisterItem('boombox', function(source, item)
    local metadata = item.info or item.metadata or {}
    TriggerClientEvent('7h-boombox:client:startPlacing', source, metadata)
end)

-- 2. Usable Item: BLANK CASSETTE (Burning Mixtape)
RegisterItem(Config.Mixtapes.BlankTapeItem, function(source, item)
    TriggerClientEvent('7h-boombox:client:openBurnerUI', source)
end)

-- 3. Usable Item: BURNED MIXTAPE (Insert into nearby boombox)
RegisterItem(Config.Mixtapes.MixtapeItem, function(source, item)
    local src = source
    local tapeData = item.info or item.metadata or {}

    -- Find closest boombox
    local pCoords = GetEntityCoords(GetPlayerPed(src))
    local closestId, closestDist = nil, 3.0

    for id, bData in pairs(ServerBoomboxes) do
        local dist = #(pCoords - bData.coords)
        if dist < closestDist then
            closestId = id
            closestDist = dist
        end
    end

    if closestId then
        local bData = ServerBoomboxes[closestId]
        if bData.tape then
            -- Already has a tape, return old one first
            Bridge.AddItem(src, Config.Mixtapes.MixtapeItem, 1, bData.tape)
        end

        Bridge.RemoveItem(src, Config.Mixtapes.MixtapeItem, 1)
        bData.tape = tapeData

        -- Auto-play the tape if it has a track
        if tapeData.url then
            bData.audioState = 'playing'
            bData.currentTrack = {
                url = tapeData.url,
                title = tapeData.label or 'Custom Mixtape',
                sourceType = 'youtube'
            }
        end

        TriggerClientEvent('7h-boombox:client:playMechanicalSfx', src, 'tape_insert')
        TriggerClientEvent('7h-boombox:client:updateState', -1, closestId, bData)
        Bridge.Notify(src, string.format("Cassette insérée : %s", tapeData.label or "Sans titre"), 'success')
    else
        Bridge.Notify(src, "Aucune boombox à proximité pour insérer la cassette !", 'error')
    end
end)

-- 4. Usable Item: POWERBANK (Recharge battery)
RegisterItem(Config.Battery.RechargeItem, function(source, item)
    local src = source
    local pCoords = GetEntityCoords(GetPlayerPed(src))
    local closestId, closestDist = nil, 3.0

    for id, bData in pairs(ServerBoomboxes) do
        local dist = #(pCoords - bData.coords)
        if dist < closestDist then
            closestId = id
            closestDist = dist
        end
    end

    if closestId then
        local bData = ServerBoomboxes[closestId]
        Bridge.RemoveItem(src, Config.Battery.RechargeItem, 1)

        bData.battery = math.min(100, bData.battery + (Config.Battery.RechargeAmount or 50))
        TriggerClientEvent('7h-boombox:client:updateState', -1, closestId, bData)
        TriggerClientEvent('7h-boombox:client:playMechanicalSfx', src, 'power_on')
        Bridge.Notify(src, _L('battery_charged'), 'success')
    else
        Bridge.Notify(src, "Aucune boombox à proximité à recharger !", 'error')
    end
end)

-- Server Event: Burn Blank Cassette into Mixtape
RegisterNetEvent('7h-boombox:server:burnMixtape', function(tapeInput)
    local src = source
    local blankItem = Config.Mixtapes.BlankTapeItem

    if not Bridge.HasItem(src, blankItem, 1) then
        Bridge.Notify(src, "Vous n'avez pas de cassette vierge !", 'error')
        return
    end

    if not tapeInput.label or tapeInput.label == '' then
        Bridge.Notify(src, _L('tape_name_empty'), 'error')
        return
    end

    if not tapeInput.url or tapeInput.url == '' then
        Bridge.Notify(src, _L('invalid_url'), 'error')
        return
    end

    Bridge.RemoveItem(src, blankItem, 1)

    local metadata = {
        label = string.sub(tapeInput.label, 1, Config.Mixtapes.MaxLabelLength),
        url = tapeInput.url,
        genre = tapeInput.genre or 'Mixtape',
        description = string.format("Titre: %s | Genre: %s", tapeInput.label, tapeInput.genre or "Custom")
    }

    Bridge.AddItem(src, Config.Mixtapes.MixtapeItem, 1, metadata)
    TriggerClientEvent('7h-boombox:client:playMechanicalSfx', src, 'click')
    Bridge.Notify(src, string.format(_L('tape_burned'), metadata.label), 'success')
end)
