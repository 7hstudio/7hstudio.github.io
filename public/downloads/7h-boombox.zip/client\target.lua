-- =========================================================================
-- 🎯 7H BEATSTORM 3D • TARGET & INTERACTION HANDLERS
-- =========================================================================

local boomboxModels = {
    Config.Props.DefaultModel,
    Config.Props.RetroModel
}

-- Helper to find active boombox ID from entity
local function GetBoomboxIdFromEntity(entity)
    for id, bData in pairs(ActiveBoomboxes) do
        if bData.entity == entity then
            return id
        end
    end
    -- Fallback distance search
    local eCoords = GetEntityCoords(entity)
    for id, bData in pairs(ActiveBoomboxes) do
        if bData.coords and #(bData.coords - eCoords) < 1.2 then
            return id
        end
    end
    return nil
end

-- Initialize Target Options
CreateThread(function()
    Wait(1000)

    -- =====================================================================
    -- 1. OX_TARGET INTEGRATION
    -- =====================================================================
    if Bridge.Target == 'ox_target' and exports.ox_target then
        exports.ox_target:addModel(boomboxModels, {
            {
                name = '7h_boombox_open',
                icon = 'fas fa-music',
                label = _L('open_boombox'),
                distance = 2.2,
                onSelect = function(data)
                    local bId = GetBoomboxIdFromEntity(data.entity)
                    if bId then OpenBoomboxUI(bId) end
                end
            },
            {
                name = '7h_boombox_carry_shoulder',
                icon = 'fas fa-user-ninja',
                label = _L('carry_shoulder'),
                distance = 2.0,
                canInteract = function() return not IsCarryingBoombox() end,
                onSelect = function(data)
                    local bId = GetBoomboxIdFromEntity(data.entity)
                    if bId then StartCarrying(bId, 'shoulder') end
                end
            },
            {
                name = '7h_boombox_carry_hand',
                icon = 'fas fa-hand-holding',
                label = _L('carry_hand'),
                distance = 2.0,
                canInteract = function() return not IsCarryingBoombox() end,
                onSelect = function(data)
                    local bId = GetBoomboxIdFromEntity(data.entity)
                    if bId then StartCarrying(bId, 'hand') end
                end
            },
            {
                name = '7h_boombox_recharge',
                icon = 'fas fa-battery-charging',
                label = _L('recharge_battery'),
                distance = 2.0,
                canInteract = function() return Config.Battery.Enabled end,
                onSelect = function(data)
                    local bId = GetBoomboxIdFromEntity(data.entity)
                    if bId then
                        TriggerServerEvent('7h-boombox:server:rechargeBattery', bId)
                    end
                end
            },
            {
                name = '7h_boombox_pickup',
                icon = 'fas fa-box-archive',
                label = _L('pickup_boombox'),
                distance = 2.0,
                onSelect = function(data)
                    local bId = GetBoomboxIdFromEntity(data.entity)
                    if bId then
                        local animDict = 'anim@mp_snowball'
                        RequestAnimDict(animDict)
                        while not HasAnimDictLoaded(animDict) do Wait(10) end
                        TaskPlayAnim(PlayerPedId(), animDict, 'pickup_snowball', 8.0, -8.0, 1200, 49, 0, false, false, false)
                        Wait(900)
                        TriggerServerEvent('7h-boombox:server:pickupBoombox', bId)
                    end
                end
            }
        })

        -- Target for Vehicles (Dock / Undock)
        exports.ox_target:addGlobalVehicle({
            {
                name = '7h_boombox_dock_trunk',
                icon = 'fas fa-car-battery',
                label = _L('dock_in_trunk'),
                distance = 2.5,
                bones = Config.VehicleTrunk.TrunkBones,
                canInteract = function(entity)
                    return IsCarryingBoombox() and (GetVehicleDoorAngleRatio(entity, 5) > 0.1)
                end,
                onSelect = function(data)
                    DockBoomboxInTrunk(exports['7h-boombox']:GetActiveBoombox() or 1, data.entity)
                end
            },
            {
                name = '7h_boombox_trunk_controls',
                icon = 'fas fa-sliders',
                label = 'Audio Party Trunk',
                distance = 2.5,
                bones = Config.VehicleTrunk.TrunkBones,
                canInteract = function(entity)
                    local vehNetId = VehToNet(entity)
                    for _, bData in pairs(ActiveBoomboxes) do
                        if bData.isDocked and bData.vehicleNetId == vehNetId then
                            return true
                        end
                    end
                    return false
                end,
                onSelect = function(data)
                    local vehNetId = VehToNet(data.entity)
                    for bId, bData in pairs(ActiveBoomboxes) do
                        if bData.isDocked and bData.vehicleNetId == vehNetId then
                            OpenBoomboxUI(bId)
                            break
                        end
                    end
                end
            },
            {
                name = '7h_boombox_undock_trunk',
                icon = 'fas fa-hand-holding-box',
                label = _L('undock_from_trunk'),
                distance = 2.5,
                bones = Config.VehicleTrunk.TrunkBones,
                canInteract = function(entity)
                    local vehNetId = VehToNet(entity)
                    for _, bData in pairs(ActiveBoomboxes) do
                        if bData.isDocked and bData.vehicleNetId == vehNetId then
                            return true
                        end
                    end
                    return false
                end,
                onSelect = function(data)
                    local vehNetId = VehToNet(data.entity)
                    for bId, bData in pairs(ActiveBoomboxes) do
                        if bData.isDocked and bData.vehicleNetId == vehNetId then
                            UndockBoomboxFromTrunk(bId)
                            break
                        end
                    end
                end
            }
        })

    -- =====================================================================
    -- 2. QB-TARGET INTEGRATION
    -- =====================================================================
    elseif Bridge.Target == 'qb-target' and exports['qb-target'] then
        exports['qb-target']:AddTargetModel(boomboxModels, {
            options = {
                {
                    icon = 'fas fa-music',
                    label = _L('open_boombox'),
                    action = function(entity)
                        local bId = GetBoomboxIdFromEntity(entity)
                        if bId then OpenBoomboxUI(bId) end
                    end
                },
                {
                    icon = 'fas fa-user-ninja',
                    label = _L('carry_shoulder'),
                    canInteract = function() return not IsCarryingBoombox() end,
                    action = function(entity)
                        local bId = GetBoomboxIdFromEntity(entity)
                        if bId then StartCarrying(bId, 'shoulder') end
                    end
                },
                {
                    icon = 'fas fa-hand-holding',
                    label = _L('carry_hand'),
                    canInteract = function() return not IsCarryingBoombox() end,
                    action = function(entity)
                        local bId = GetBoomboxIdFromEntity(entity)
                        if bId then StartCarrying(bId, 'hand') end
                    end
                },
                {
                    icon = 'fas fa-battery-charging',
                    label = _L('recharge_battery'),
                    canInteract = function() return Config.Battery.Enabled end,
                    action = function(entity)
                        local bId = GetBoomboxIdFromEntity(entity)
                        if bId then TriggerServerEvent('7h-boombox:server:rechargeBattery', bId) end
                    end
                },
                {
                    icon = 'fas fa-box-archive',
                    label = _L('pickup_boombox'),
                    action = function(entity)
                        local bId = GetBoomboxIdFromEntity(entity)
                        if bId then
                            local animDict = 'anim@mp_snowball'
                            RequestAnimDict(animDict)
                            while not HasAnimDictLoaded(animDict) do Wait(10) end
                            TaskPlayAnim(PlayerPedId(), animDict, 'pickup_snowball', 8.0, -8.0, 1200, 49, 0, false, false, false)
                            Wait(900)
                            TriggerServerEvent('7h-boombox:server:pickupBoombox', bId)
                        end
                    end
                }
            },
            distance = 2.2
        })
    end
end)
