-- =========================================================================
-- 📦 7H BEATSTORM 3D • RAYCAST PLACEMENT GIZMO
-- =========================================================================

local isPlacing = false
local ghostEntity = nil
local currentHeading = 0.0

-- Perform Raycast from Screen / Camera into the 3D World
local function RaycastFromCamera(distance)
    local camCoords = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)

    local pitch = math.rad(camRot.x)
    local yaw = math.rad(camRot.z)

    local dir = vector3(
        -math.sin(yaw) * math.cos(pitch),
        math.cos(yaw) * math.cos(pitch),
        math.sin(pitch)
    )

    local destination = camCoords + (dir * distance)

    local ray = StartShapeTestRay(
        camCoords.x, camCoords.y, camCoords.z,
        destination.x, destination.y, destination.z,
        1 | 2 | 16, -- World, vehicles, objects
        PlayerPedId(),
        4
    )

    local retval, hit, endCoords, surfaceNormal, entityHit = GetShapeTestResult(ray)
    return hit, endCoords, surfaceNormal
end

-- Start Placement Gizmo
function StartBoomboxPlacement(sourceItemData)
    if isPlacing then return end
    isPlacing = true

    local ped = PlayerPedId()
    currentHeading = GetEntityHeading(ped)

    -- Request Prop Model
    local model = Config.Props.DefaultModel
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(10) end

    -- Spawn Ghost Entity
    local pedCoords = GetEntityCoords(ped)
    ghostEntity = CreateObject(model, pedCoords.x, pedCoords.y, pedCoords.z, false, false, false)
    SetEntityAlpha(ghostEntity, 195, false)
    SetEntityCollision(ghostEntity, false, false)
    SetEntityInvincible(ghostEntity, true)

    CreateThread(function()
        while isPlacing do
            Wait(0)
            local hit, hitCoords, surfaceNormal = RaycastFromCamera(5.0)

            local pCoords = GetEntityCoords(ped)
            local validPlacement = false
            local targetPos = hitCoords

            if hit ~= 0 and hitCoords ~= vector3(0,0,0) then
                local dist = #(pCoords - hitCoords)
                if dist <= 3.8 then
                    validPlacement = true
                    targetPos = hitCoords
                else
                    validPlacement = false
                end
            else
                targetPos = pCoords + (GetEntityForwardVector(ped) * 1.5)
            end

            -- Update Ghost Position & Rotation
            SetEntityCoords(ghostEntity, targetPos.x, targetPos.y, targetPos.z, false, false, false, false)
            SetEntityHeading(ghostEntity, currentHeading)

            -- Color Tint Gizmo: Green if valid, Red if invalid
            if validPlacement then
                SetEntityDrawOutline(ghostEntity, true)
                SetEntityDrawOutlineColor(34, 197, 94, 200)
            else
                SetEntityDrawOutline(ghostEntity, true)
                SetEntityDrawOutlineColor(239, 68, 68, 200)
            end

            -- Display Controls
            BeginTextCommandDisplayHelp("STRING")
            AddTextComponentSubstringPlayerName(_L('controls_help'))
            EndTextCommandDisplayHelp(0, false, false, -1)

            -- Controls: Rotate Gizmo with Scroll or Arrow keys
            DisableControlAction(0, 14, true)  -- INPUT_WEAPON_WHEEL_NEXT
            DisableControlAction(0, 15, true)  -- INPUT_WEAPON_WHEEL_PREV
            DisableControlAction(0, 24, true)  -- Attack
            DisableControlAction(0, 25, true)  -- Aim

            if IsDisabledControlJustPressed(0, 14) or IsControlPressed(0, 174) then -- Scroll down / Left
                currentHeading = (currentHeading + 5.0) % 360.0
            elseif IsDisabledControlJustPressed(0, 15) or IsControlPressed(0, 175) then -- Scroll up / Right
                currentHeading = (currentHeading - 5.0) % 360.0
            end

            -- Confirm Placement: [E] or Left Click
            if IsControlJustPressed(0, 38) or IsDisabledControlJustPressed(0, 24) then
                if validPlacement then
                    isPlacing = false

                    -- Delete Ghost
                    if DoesEntityExist(ghostEntity) then
                        DeleteEntity(ghostEntity)
                        ghostEntity = nil
                    end

                    -- Bending Placement Animation
                    local animDict = 'anim@mp_snowball'
                    RequestAnimDict(animDict)
                    while not HasAnimDictLoaded(animDict) do Wait(10) end

                    TaskPlayAnim(ped, animDict, 'pickup_snowball', 8.0, -8.0, 1400, 49, 0, false, false, false)
                    Wait(900)

                    -- Trigger Server Event
                    TriggerServerEvent('7h-boombox:server:placeBoombox', targetPos, currentHeading, sourceItemData)
                    break
                else
                    Bridge.Notify(_L('invalid_url') or 'Placement invalide !', 'error')
                end
            end

            -- Cancel Placement: [Backspace] or Right Click
            if IsControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 25) then
                isPlacing = false
                if DoesEntityExist(ghostEntity) then
                    DeleteEntity(ghostEntity)
                    ghostEntity = nil
                end
                break
            end
        end
    end)
end

RegisterNetEvent('7h-boombox:client:startPlacing', function(itemData)
    StartBoomboxPlacement(itemData)
end)
