// =========================================================================
// ⚡ 7H BEATSTORM 3D • NUI APPLICATION LOGIC & VISUALIZER LOOP
// =========================================================================

let currentBoombox = null;
let isKnobDragging = false;
let knobAngle = -135; // Default angle for 0% to +135 for 100%
let visualizerAnimationFrame = null;

// Get FiveM Resource Name safely
function GetParentResourceName() {
  return window.GetParentResourceName ? window.GetParentResourceName() : '7h-boombox';
}

// =========================================================================
// WINDOW EVENT LISTENER FOR FIVEM NUI MESSAGES
// =========================================================================
window.addEventListener('message', (event) => {
  const data = event.data;
  if (!data || !data.action) return;

  switch (data.action) {
    case 'openUI':
      currentBoombox = data.boombox;
      openDeckUI(data.boombox, data.presets);
      break;

    case 'closeUI':
      closeDeckUI();
      break;

    case 'syncAudioState':
      handleAudioSync(data.boombox);
      break;

    case 'refreshUI':
      if (currentBoombox && currentBoombox.id === data.boombox.id) {
        currentBoombox = data.boombox;
        updateDeckDisplay(data.boombox);
      }
      break;

    case 'updateSpatialBatch':
      if (typeof updateSpatialBatch === 'function') {
        updateSpatialBatch(data.batch, data.listenerForward);
      }
      break;

    case 'playSfx':
      if (typeof playSynthesizedSfx === 'function') {
        playSynthesizedSfx(data.sound);
      }
      break;

    case 'openBurner':
      openBurnerModal();
      break;

    case 'stopAudio':
      if (typeof stopBoomboxAudio === 'function') {
        stopBoomboxAudio(data.id);
      }
      break;
  }
});

// Escape key closes UI
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeDeckUI();
  }
});

// =========================================================================
// UI DISPLAY & TELEMETRY UPDATES
// =========================================================================
function openDeckUI(boombox, presets) {
  const overlay = document.getElementById('deck-overlay');
  overlay.style.display = 'flex';

  updateDeckDisplay(boombox);
  renderFmPresets(presets || []);

  // Initialize Volume Knob position
  const vol = boombox.volume !== undefined ? boombox.volume : 0.65;
  setKnobVolume(vol, false);

  // Start Visualizer Canvas Render Loop
  startVisualizerLoop();
}

function closeDeckUI() {
  const overlay = document.getElementById('deck-overlay');
  overlay.style.display = 'none';

  if (visualizerAnimationFrame) {
    cancelAnimationFrame(visualizerAnimationFrame);
    visualizerAnimationFrame = null;
  }

  fetch(`https://${GetParentResourceName()}/closeUI`, {
    method: 'POST',
    body: JSON.stringify({})
  }).catch(() => {});
}

function updateDeckDisplay(boombox) {
  if (!boombox) return;

  // 1. Battery Gauge
  const batVal = document.getElementById('battery-val');
  const batFill = document.getElementById('battery-bar-fill');
  const batIcon = document.getElementById('battery-icon');
  const bat = Math.max(0, Math.min(100, Math.round(boombox.battery || 100)));

  if (batVal) batVal.textContent = `${bat}%`;
  if (batFill) {
    batFill.style.width = `${bat}%`;
    if (bat < 20) {
      batFill.style.background = 'linear-gradient(90deg, #ef4444, #f59e0b)';
      if (batIcon) batIcon.style.color = '#ef4444';
    } else {
      batFill.style.background = 'linear-gradient(90deg, #10b981, #06b6d4)';
      if (batIcon) batIcon.style.color = '#10b981';
    }
  }

  // 2. Status Badge
  const statusText = document.getElementById('deck-status-text');
  if (statusText) {
    if (boombox.isDocked) statusText.textContent = 'VEHICLE TRUNK DOCKED';
    else if (boombox.isCarried) statusText.textContent = 'CARRIED ON SHOULDER';
    else statusText.textContent = 'STANDALONE GROUND';
  }

  // 3. Cassette Tape Label & Motor Spools
  const tapeLabel = document.getElementById('tape-marker-text');
  const spoolLeft = document.getElementById('spool-left');
  const spoolRight = document.getElementById('spool-right');

  if (tapeLabel) {
    if (boombox.tape && boombox.tape.label) {
      tapeLabel.textContent = `SIDE A • ${boombox.tape.label.toUpperCase()}`;
    } else if (boombox.currentTrack && boombox.currentTrack.title) {
      tapeLabel.textContent = `STREAM • ${boombox.currentTrack.title.toUpperCase()}`;
    } else {
      tapeLabel.textContent = 'SIDE A • EMPTY DECK';
    }
  }

  // Spinning tape spools if playing
  if (boombox.audioState === 'playing') {
    if (spoolLeft) spoolLeft.classList.add('spinning');
    if (spoolRight) spoolRight.classList.add('spinning');
  } else {
    if (spoolLeft) spoolLeft.classList.remove('spinning');
    if (spoolRight) spoolRight.classList.remove('spinning');
  }

  // 4. MegaBass Switch
  const btnMegaBass = document.getElementById('btn-megabass');
  const megaStatus = document.getElementById('megabass-status');
  if (btnMegaBass && megaStatus) {
    if (boombox.megaBass) {
      btnMegaBass.classList.add('active');
      megaStatus.textContent = 'BOOST ACTIVE';
    } else {
      btnMegaBass.classList.remove('active');
      megaStatus.textContent = 'OFF';
    }
  }

  // 5. Equalizer Sliders
  if (boombox.eq) {
    const bass = document.getElementById('eq-bass');
    const mid = document.getElementById('eq-mid');
    const treb = document.getElementById('eq-treble');
    if (bass) { bass.value = boombox.eq.bass || 0; document.getElementById('eq-bass-val').textContent = `${bass.value}dB`; }
    if (mid) { mid.value = boombox.eq.mid || 0; document.getElementById('eq-mid-val').textContent = `${mid.value}dB`; }
    if (treb) { treb.value = boombox.eq.treble || 0; document.getElementById('eq-treble-val').textContent = `${treb.value}dB`; }
  }
}

// Sync Audio State from Server
function handleAudioSync(boombox) {
  if (!boombox) return;

  if (boombox.audioState === 'playing') {
    if (typeof playBoomboxAudio === 'function') {
      playBoomboxAudio(boombox);
    }
  } else if (boombox.audioState === 'paused') {
    if (typeof pauseBoomboxAudio === 'function') {
      pauseBoomboxAudio(boombox.id);
    }
  } else {
    if (typeof stopBoomboxAudio === 'function') {
      stopBoomboxAudio(boombox.id);
    }
  }
}

// =========================================================================
// ROTARY MASTER VOLUME KNOB DRAGGING INTERACTION
// =========================================================================
const knobContainer = document.getElementById('volume-knob-container');
const volumeKnob = document.getElementById('volume-knob');
const knobDisplay = document.getElementById('knob-value-display');
const knobLedRing = document.getElementById('knob-led-ring');

if (knobContainer) {
  knobContainer.addEventListener('mousedown', (e) => {
    isKnobDragging = true;
    updateKnobRotation(e);
  });
}

window.addEventListener('mousemove', (e) => {
  if (!isKnobDragging) return;
  updateKnobRotation(e);
});

window.addEventListener('mouseup', () => {
  if (isKnobDragging) {
    isKnobDragging = false;
    // Dispatch final volume to server
    const normalizedVol = Math.max(0, Math.min(1, (knobAngle + 135) / 270));
    fetch(`https://${GetParentResourceName()}/setVolume`, {
      method: 'POST',
      body: JSON.stringify({ volume: normalizedVol })
    }).catch(() => {});
  }
});

function updateKnobRotation(e) {
  const rect = knobContainer.getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;

  const dx = e.clientX - centerX;
  const dy = e.clientY - centerY;

  let angle = Math.atan2(dy, dx) * (180 / Math.PI) + 90;
  if (angle > 180) angle -= 360;

  // Clamp angle to -135deg -> +135deg (270 degrees sweep)
  if (angle < -135) angle = -135;
  if (angle > 135) angle = 135;

  knobAngle = angle;
  const percent = Math.round(((angle + 135) / 270) * 100);

  if (volumeKnob) volumeKnob.style.transform = `rotate(${angle}deg)`;
  if (knobDisplay) knobDisplay.textContent = `${percent}%`;

  // Update LED gauge ring
  const ledSweep = Math.round(((angle + 135) / 270) * 270);
  if (knobLedRing) {
    knobLedRing.style.background = `conic-gradient(var(--accent-purple) 0deg, var(--accent-purple) ${ledSweep}deg, rgba(255, 255, 255, 0.08) ${ledSweep}deg, rgba(255, 255, 255, 0.08) 360deg)`;
  }
}

function setKnobVolume(vol, sendEvent = true) {
  const angle = -135 + (vol * 270);
  knobAngle = angle;
  const percent = Math.round(vol * 100);

  if (volumeKnob) volumeKnob.style.transform = `rotate(${angle}deg)`;
  if (knobDisplay) knobDisplay.textContent = `${percent}%`;

  const ledSweep = Math.round(vol * 270);
  if (knobLedRing) {
    knobLedRing.style.background = `conic-gradient(var(--accent-purple) 0deg, var(--accent-purple) ${ledSweep}deg, rgba(255, 255, 255, 0.08) ${ledSweep}deg, rgba(255, 255, 255, 0.08) 360deg)`;
  }

  if (sendEvent) {
    fetch(`https://${GetParentResourceName()}/setVolume`, {
      method: 'POST',
      body: JSON.stringify({ volume: vol })
    }).catch(() => {});
  }
}

// =========================================================================
// EQUALIZER & MEGABASS CONTROLS
// =========================================================================
function toggleMegaBass() {
  if (!currentBoombox) return;
  currentBoombox.megaBass = !currentBoombox.megaBass;

  updateDeckDisplay(currentBoombox);
  onEqSliderChange();

  // Play punchy sub-bass SFX
  if (currentBoombox.megaBass && typeof playSynthesizedSfx === 'function') {
    playSynthesizedSfx('power_on');
  }
}

function onEqSliderChange() {
  const bass = document.getElementById('eq-bass').value;
  const mid = document.getElementById('eq-mid').value;
  const treb = document.getElementById('eq-treble').value;

  document.getElementById('eq-bass-val').textContent = `${bass}dB`;
  document.getElementById('eq-mid-val').textContent = `${mid}dB`;
  document.getElementById('eq-treble-val').textContent = `${treb}dB`;

  fetch(`https://${GetParentResourceName()}/setEq`, {
    method: 'POST',
    body: JSON.stringify({
      eq: { bass: Number(bass), mid: Number(mid), treble: Number(treb) },
      megaBass: currentBoombox ? currentBoombox.megaBass : false
    })
  }).catch(() => {});
}

// =========================================================================
// RGB AURA CONTROLLER
// =========================================================================
function setRgbMode(mode) {
  document.querySelectorAll('.btn-pill').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-mode') === mode);
  });

  fetch(`https://${GetParentResourceName()}/setRgb`, {
    method: 'POST',
    body: JSON.stringify({
      mode: mode,
      color: currentBoombox ? currentBoombox.rgbColor : '#8b5cf6'
    })
  }).catch(() => {});
}

function setRgbColor(color) {
  document.querySelectorAll('.swatch').forEach(s => {
    s.classList.toggle('active', s.style.background === color);
  });

  fetch(`https://${GetParentResourceName()}/setRgb`, {
    method: 'POST',
    body: JSON.stringify({
      mode: currentBoombox ? currentBoombox.rgbMode : 'beat',
      color: color
    })
  }).catch(() => {});
}

// =========================================================================
// TRANSPORT CONTROLS & URL STREAM LOADING
// =========================================================================
function loadEnteredStream() {
  const input = document.getElementById('stream-url-input');
  const url = input.value.trim();
  if (!url) return;

  fetch(`https://${GetParentResourceName()}/playTrack`, {
    method: 'POST',
    body: JSON.stringify({
      url: url,
      title: 'Direct Stream',
      sourceType: url.includes('youtu') ? 'youtube' : 'stream'
    })
  }).catch(() => {});

  input.value = '';
}

function pauseActiveTrack() {
  fetch(`https://${GetParentResourceName()}/pauseTrack`, {
    method: 'POST',
    body: JSON.stringify({})
  }).catch(() => {});
}

function resumeActiveTrack() {
  fetch(`https://${GetParentResourceName()}/resumeTrack`, {
    method: 'POST',
    body: JSON.stringify({})
  }).catch(() => {});
}

function stopActiveTrack() {
  pauseActiveTrack();
}

function ejectInsertedTape() {
  fetch(`https://${GetParentResourceName()}/ejectTape`, {
    method: 'POST',
    body: JSON.stringify({})
  }).catch(() => {});
}

// =========================================================================
// BUILT-IN FM PRESET BUTTONS
// =========================================================================
function renderFmPresets(presets) {
  const container = document.getElementById('presets-scroll-list');
  if (!container) return;
  container.innerHTML = '';

  presets.forEach(p => {
    const chip = document.createElement('div');
    chip.className = 'preset-chip';
    chip.innerHTML = `<strong>${p.name}</strong> • <span style="opacity:0.7">${p.genre}</span>`;
    chip.onclick = () => {
      fetch(`https://${GetParentResourceName()}/playTrack`, {
        method: 'POST',
        body: JSON.stringify({
          url: p.streamUrl,
          title: p.name,
          sourceType: 'stream'
        })
      }).catch(() => {});
    };
    container.appendChild(chip);
  });
}

// =========================================================================
// REAL-TIME CANVAS AUDIO VISUALIZER LOOP
// =========================================================================
const canvas = document.getElementById('audio-visualizer-canvas');
const ctx = canvas ? canvas.getContext('2d') : null;

function startVisualizerLoop() {
  if (!ctx || visualizerAnimationFrame) return;

  function renderFrame() {
    visualizerAnimationFrame = requestAnimationFrame(renderFrame);

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Get active boombox audio analyser
    let dataArray = null;
    if (currentBoombox && typeof audioNodes !== 'undefined' && audioNodes[currentBoombox.id]) {
      const graph = audioNodes[currentBoombox.id];
      if (graph.analyserNode) {
        graph.analyserNode.getByteFrequencyData(graph.dataArray);
        dataArray = graph.dataArray;
      }
    }

    const barCount = 36;
    const barWidth = (canvas.width / barCount) - 3;

    for (let i = 0; i < barCount; i++) {
      let val = 8; // Baseline idle value
      if (dataArray && currentBoombox && currentBoombox.audioState === 'playing') {
        const binIndex = Math.floor((i / barCount) * (dataArray.length / 2));
        val = Math.max(8, dataArray[binIndex] || 8);
      }

      const barHeight = (val / 255) * (canvas.height - 15);
      const x = i * (barWidth + 3) + 2;
      const y = canvas.height - barHeight - 4;

      // Dynamic Gradient based on frequency range
      const grad = ctx.createLinearGradient(0, canvas.height, 0, 0);
      if (currentBoombox && currentBoombox.megaBass) {
        grad.addColorStop(0, '#8b5cf6');
        grad.addColorStop(0.6, '#ec4899');
        grad.addColorStop(1, '#06b6d4');
      } else {
        grad.addColorStop(0, '#8b5cf6');
        grad.addColorStop(1, '#06b6d4');
      }

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.roundRect(x, y, barWidth, barHeight, [3, 3, 0, 0]);
      ctx.fill();

      // Top glowing dot
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(x, y - 2, barWidth, 2);
    }

    // Update VU Bars
    const vuL = document.getElementById('vu-left');
    const vuR = document.getElementById('vu-right');
    if (dataArray && currentBoombox && currentBoombox.audioState === 'playing') {
      const leftPwr = (dataArray[2] / 255) * 100;
      const rightPwr = (dataArray[8] / 255) * 100;
      if (vuL) vuL.style.width = `${Math.min(100, leftPwr)}%`;
      if (vuR) vuR.style.width = `${Math.min(100, rightPwr)}%`;
    } else {
      if (vuL) vuL.style.width = '4%';
      if (vuR) vuR.style.width = '4%';
    }
  }

  renderFrame();
}

// =========================================================================
// MIXTAPE BURNING MODAL
// =========================================================================
function openBurnerModal() {
  const modal = document.getElementById('burner-modal');
  if (modal) modal.style.display = 'flex';
}

function closeBurnerModal() {
  const modal = document.getElementById('burner-modal');
  if (modal) modal.style.display = 'none';
  fetch(`https://${GetParentResourceName()}/closeUI`, {
    method: 'POST',
    body: JSON.stringify({})
  }).catch(() => {});
}

function submitBurnMixtape() {
  const label = document.getElementById('burner-label-input').value.trim();
  const url = document.getElementById('burner-url-input').value.trim();
  const genre = document.getElementById('burner-genre-select').value;

  if (!label || !url) return;

  fetch(`https://${GetParentResourceName()}/burnTape`, {
    method: 'POST',
    body: JSON.stringify({
      label: label,
      url: url,
      genre: genre
    })
  }).catch(() => {});

  closeBurnerModal();
}
