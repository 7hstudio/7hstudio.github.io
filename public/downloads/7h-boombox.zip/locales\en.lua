Locales = Locales or {}

Locales['en'] = {
    ['open_boombox'] = 'Open Audio Deck',
    ['pickup_boombox'] = 'Pick up Boombox',
    ['carry_shoulder'] = 'Carry on Shoulder',
    ['carry_hand'] = 'Carry in Hand',
    ['drop_boombox'] = 'Place on Ground',
    ['pass_to_friend'] = 'Pass to Friend',
    ['dock_in_trunk'] = 'Dock into Trunk',
    ['undock_from_trunk'] = 'Remove from Trunk',
    ['burn_tape'] = 'Burn Mixtape',
    ['recharge_battery'] = 'Recharge Battery',
    ['insert_tape'] = 'Insert Cassette',
    ['eject_tape'] = 'Eject Cassette',
    ['low_battery_warn'] = 'Battery critical! Boombox will shut down shortly...',
    ['battery_dead'] = 'Boombox battery is completely drained.',
    ['battery_charged'] = 'Boombox battery successfully recharged!',
    ['no_powerbank'] = 'You do not have a Powerbank in your pockets!',
    ['trunk_docked'] = 'Boombox successfully docked into vehicle trunk!',
    ['trunk_undocked'] = 'Boombox undocked from vehicle trunk.',
    ['trunk_not_open'] = 'The vehicle trunk must be open first!',
    ['invalid_vehicle'] = 'This vehicle does not support an audio dock.',
    ['already_carrying'] = 'You are already carrying a boombox!',
    ['handed_to_friend'] = 'Boombox handed to your friend!',
    ['no_one_nearby'] = 'No one nearby to receive the boombox.',
    ['tape_burned'] = 'Mixtape recorded successfully: %s',
    ['tape_name_empty'] = 'Cassette label cannot be empty!',
    ['invalid_url'] = 'Invalid audio stream or YouTube URL.',
    ['controls_help'] = '~INPUT_CONTEXT~ Place | ~INPUT_VEH_HEADLIGHT~ Rotate | ~INPUT_CELLPHONE_CANCEL~ Cancel'
}

function _L(key, ...)
    local lang = Config.Locale or 'fr'
    local str = (Locales[lang] and Locales[lang][key]) or (Locales['en'] and Locales['en'][key]) or key
    if ... then
        return string.format(str, ...)
    end
    return str
end
