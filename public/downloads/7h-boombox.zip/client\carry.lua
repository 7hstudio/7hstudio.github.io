-- =========================================================================
-- 🎒 7H BEATSTORM 3D • MULTI-STANCE CARRY & PEER HANDOFF
-- =========================================================================

local carriedProp = nil
local carriedBoomboxId = nil
local currentStance = nil

function IsCarryingBoombox()
    return (carriedProp ~= nil and DoesEntityExist(carriedProp))
end

exports('IsCarryingBoombox', IsCarryingBoombox)

-- Start Carrying Boombox
function StartCarrying(boomboxId, stance)
    if IsCarryingBoombox() then
        Bridge.Notify(_L('already_carrying'), 'error')
        return
    end

    local bData = ActiveBoomboxes[boomboxId]
    if not bData then return end

    stance = stance or 'shoulder'
    local ped = PlayerPedId()
    local configStance = (stance == 'hand') and Config.Props.HandCarry or Config.Props.ShoulderCarry

    -- Request Animation
    RequestAnimDict(configStance.animDict)
    while not HasAnimDictLoaded(configStance.animDict) do Wait(10) end

    -- Request Prop Model
    local model = Config.Props.DefaultModel
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(10) end

    -- Delete World Entity if Placed
    if bData.entity and DoesEntityExist(bData.entity) then
        DeleteEntity(bData.entity)
        bData.entity = nil
    end

    -- Create Carried Prop
    local pCoords = GetEntityCoords(ped)
    carriedProp = CreateObject(model, pCoords.x, pCoords.y, pCoords.z, true, true, true)
    SetEntityCollision(carriedProp, false, false)

    -- Attach to Ped Bone
    local boneIndex = GetPedBoneIndex(ped, configStance.bone)
    AttachEntityToEntity(
        carriedProp, ped, boneIndex,
        configStance.offset.x, configStance.offset.y, configStance.offset.z,
        configStance.rotation.x, configStance.rotation.y, configStance.rotation.z,
        true, true, false, true, 1, true
    )

    carriedBoomboxId = boomboxId
    currentStance = stance

    -- Play Animation Loop
    TaskPlayAnim(ped, configStance.animDict, configStance.animClip, 8.0, -8.0, -1, 49, 0, false, false, false)

    -- Inform Server
    TriggerServerEvent('7h-boombox:server:setCarried', boomboxId, true, stance)

    -- Monitor Carrying Thread (Auto-Drop if Dead or in Vehicle)
    CreateThread(function()
        while IsCarryingBoombox() do
            Wait(250)
            local myPed = PlayerPedId()

            if IsPedDeadOrDying(myPed, true) or IsPedInAnyVehicle(myPed, false) or IsPedRagdoll(myPed) then
                StopCarrying(carriedBoomboxId, true)
                break
            end

            -- Ensure Anim is Still Playing if Standing/Walking
            if not IsEntityPlayingAnim(myPed, configStance.animDict, configStance.animClip, 3) and not IsPedRunning(myPed) and not IsPedSprinting(myPed) then
                TaskPlayAnim(myPed, configStance.animDict, configStance.animClip, 8.0, -8.0, -1, 49, 0, false, false, false)
            end
        end
    end)
end

-- Stop Carrying Boombox
function StopCarrying(boomboxId, dropToGround)
    if not IsCarryingBoombox() then return end

    local ped = PlayerPedId()
    ClearPedTasks(ped)

    local dropCoords = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.7, -0.9)
    local dropHeading = GetEntityHeading(ped)

    if DoesEntityExist(carriedProp) then
        DeleteEntity(carriedProp)
        carriedProp = nil
    end

    local bId = boomboxId or carriedBoomboxId
    carriedBoomboxId = nil
    currentStance = nil

    if dropToGround then
        TriggerServerEvent('7h-boombox:server:placeBoombox', dropCoords, dropHeading, { id = bId })
    else
        TriggerServerEvent('7h-boombox:server:setCarried', bId, false, nil)
    end
end

-- Pass Boombox to Closest Friend
function PassBoomboxToFriend(boomboxId)
    local ped = PlayerPedId()
    local myCoords = GetEntityCoords(ped)

    -- Find closest player
    local closestPlayer, closestDist = -1, 3.0
    for _, player in ipairs(GetActivePlayers()) do
        if player ~= PlayerId() then
            local targetPed = GetPlayerPed(player)
            local dist = #(myCoords - GetEntityCoords(targetPed))
            if dist < closestDist then
                closestPlayer = player
                closestDist = dist
            end
        end
    end

    if closestPlayer == -1 then
        Bridge.Notify(_L('no_one_nearby'), 'error')
        return
    end

    local targetServerId = GetPlayerServerId(closestPlayer)

    -- Play Handoff Animation
    local animDict = 'mp_common'
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Wait(10) end

    TaskPlayAnim(ped, animDict, 'givetake2_a', 8.0, -8.0, 1800, 49, 0, false, false, false)

    -- Detach local prop
    if DoesEntityExist(carriedProp) then
        DeleteEntity(carriedProp)
        carriedProp = nil
    end

    local bId = boomboxId or carriedBoomboxId
    carriedBoomboxId = nil
    currentStance = nil

    -- Trigger Server Transfer
    TriggerServerEvent('7h-boombox:server:transferCarrier', bId, targetServerId)
    Bridge.Notify(_L('handed_to_friend'), 'success')
end

-- Networked Events for Carrying
RegisterNetEvent('7h-boombox:client:carryStance', function(boomboxId, stance)
    StartCarrying(boomboxId, stance)
end)

RegisterNetEvent('7h-boombox:client:stopCarry', function(boomboxId)
    StopCarrying(boomboxId, false)
end)

RegisterNetEvent('7h-boombox:client:passToFriend', function(boomboxId)
    PassBoomboxToFriend(boomboxId)
end)

RegisterNetEvent('7h-boombox:client:receiveBoomboxHandoff', function(boomboxId, stance)
    local ped = PlayerPedId()
    local animDict = 'mp_common'
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Wait(10) end

    TaskPlayAnim(ped, animDict, 'givetake2_b', 8.0, -8.0, 1800, 49, 0, false, false, false)
    Wait(1200)

    StartCarrying(boomboxId, stance or 'shoulder')
end)
