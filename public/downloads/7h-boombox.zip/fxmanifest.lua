fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author '7H STUDIO (7h-studio)'
description '7H BeatStorm 3D • Revolutionary Next-Gen Boombox System with 3D Occlusion Audio, Physical Mixtapes & Party Trunk Dock'
version '2.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'locales/*.lua',
    'shared/bridge.lua'
}

client_scripts {
    'client/main.lua',
    'client/audio.lua',
    'client/placing.lua',
    'client/carry.lua',
    'client/trunk.lua',
    'client/visualizer.lua',
    'client/target.lua'
}

server_scripts {
    'server/main.lua',
    'server/audio.lua',
    'server/inventory.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/app.js',
    'web/audio.js',
    'web/assets/*.*'
}

exports {
    'OpenBoomboxUI',
    'IsCarryingBoombox',
    'GetActiveBoombox',
    'PickupBoombox',
    'DockBoomboxInTrunk'
}
