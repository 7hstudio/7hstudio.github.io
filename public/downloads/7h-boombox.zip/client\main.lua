-- =========================================================================
-- ⚡ 7H BEATSTORM 3D • CLIENT MAIN CONTROLLER
-- =========================================================================
ActiveBoomboxes = {}
CurrentBoomboxId = nil
IsUIOpen = false

-- Open Boombox NUI Deck
function OpenBoomboxUI(boomboxId)
    local data = ActiveBoomboxes[boomboxId]
    if not data then return end

    CurrentBoomboxId = boomboxId
    IsUIOpen = true
    SetNuiFocus(true, true)

    SendNUIMessage({
        action = 'openUI',
        boombox = {
            id = boomboxId,
            audioState = data.audioState or 'stopped',
            currentTrack = data.currentTrack or nil,
            volume = data.volume or Config.Audio.DefaultVolume,
            megaBass = data.megaBass or false,
            eq = data.eq or { bass = 0, mid = 0, treble = 0 },
            battery = data.battery or 100,
            rgbMode = data.rgbMode or Config.RGBLights.DefaultMode,
            rgbColor = data.rgbColor or '#8b5cf6',
            tape = data.tape or nil,
            isDocked = data.isDocked or false,
            isCarried = data.isCarried or false
        },
        presets = Config.FMPresets
    })
end

exports('OpenBoomboxUI', OpenBoomboxUI)
exports('GetActiveBoombox', function() return CurrentBoomboxId end)

-- =========================================================================
-- NET EVENTS & SYNCHRONIZATION
-- =========================================================================
RegisterNetEvent('7h-boombox:client:syncAll', function(allData)
    for id, bData in pairs(allData) do
        UpdateBoomboxData(id, bData)
    end
end)

RegisterNetEvent('7h-boombox:client:updateState', function(id, bData)
    UpdateBoomboxData(id, bData)
end)

RegisterNetEvent('7h-boombox:client:remove', function(id)
    if ActiveBoomboxes[id] then
        -- Stop audio in NUI
        SendNUIMessage({
            action = 'stopAudio',
            id = id
        })

        -- Delete entity if local client owns it
        if DoesEntityExist(ActiveBoomboxes[id].entity) then
            DeleteEntity(ActiveBoomboxes[id].entity)
        end

        ActiveBoomboxes[id] = nil
    end

    if CurrentBoomboxId == id and IsUIOpen then
        SendNUIMessage({ action = 'closeUI' })
        SetNuiFocus(false, false)
        IsUIOpen = false
        CurrentBoomboxId = nil
    end
end)

RegisterNetEvent('7h-boombox:client:openUI', function(id)
    OpenBoomboxUI(id)
end)

RegisterNetEvent('7h-boombox:client:playMechanicalSfx', function(sfxType)
    SendNUIMessage({
        action = 'playSfx',
        sound = sfxType -- 'tape_insert', 'tape_eject', 'power_on', 'bass_sub', 'click'
    })
end)

function UpdateBoomboxData(id, bData)
    local existing = ActiveBoomboxes[id]
    if not existing then
        ActiveBoomboxes[id] = {
            id = id,
            coords = bData.coords,
            heading = bData.heading or 0.0,
            entity = nil,
            isCarried = bData.isCarried or false,
            carrierServerId = bData.carrierServerId,
            carrierStance = bData.carrierStance or 'shoulder',
            isDocked = bData.isDocked or false,
            vehicleNetId = bData.vehicleNetId,
            audioState = bData.audioState or 'stopped',
            currentTrack = bData.currentTrack,
            volume = bData.volume or Config.Audio.DefaultVolume,
            megaBass = bData.megaBass or false,
            eq = bData.eq or { bass = 0, mid = 0, treble = 0 },
            battery = bData.battery or 100,
            rgbMode = bData.rgbMode or 'beat',
            rgbColor = bData.rgbColor or '#8b5cf6',
            tape = bData.tape
        }
    else
        existing.coords = bData.coords
        existing.heading = bData.heading or existing.heading
        existing.isCarried = bData.isCarried
        existing.carrierServerId = bData.carrierServerId
        existing.carrierStance = bData.carrierStance or existing.carrierStance
        existing.isDocked = bData.isDocked
        existing.vehicleNetId = bData.vehicleNetId
        existing.audioState = bData.audioState
        existing.currentTrack = bData.currentTrack
        existing.volume = bData.volume
        existing.megaBass = bData.megaBass
        existing.eq = bData.eq
        existing.battery = bData.battery
        existing.rgbMode = bData.rgbMode
        existing.rgbColor = bData.rgbColor
        existing.tape = bData.tape
    end

    -- Update NUI Audio State
    SendNUIMessage({
        action = 'syncAudioState',
        boombox = ActiveBoomboxes[id]
    })

    -- Refresh UI if open on this boombox
    if CurrentBoomboxId == id and IsUIOpen then
        SendNUIMessage({
            action = 'refreshUI',
            boombox = ActiveBoomboxes[id]
        })
    end
end

-- =========================================================================
-- NUI CALLBACK HANDLERS
-- =========================================================================
RegisterNUICallback('closeUI', function(_, cb)
    SetNuiFocus(false, false)
    IsUIOpen = false
    CurrentBoomboxId = nil
    cb('ok')
end)

RegisterNUICallback('playTrack', function(data, cb)
    if not CurrentBoomboxId then cb('error') return end
    TriggerServerEvent('7h-boombox:server:playTrack', CurrentBoomboxId, {
        url = data.url,
        title = data.title or 'Unknown Track',
        sourceType = data.sourceType or 'youtube',
        duration = data.duration or 0
    })
    cb('ok')
end)

RegisterNUICallback('pauseTrack', function(_, cb)
    if not CurrentBoomboxId then cb('error') return end
    TriggerServerEvent('7h-boombox:server:pauseTrack', CurrentBoomboxId)
    cb('ok')
end)

RegisterNUICallback('resumeTrack', function(_, cb)
    if not CurrentBoomboxId then cb('error') return end
    TriggerServerEvent('7h-boombox:server:resumeTrack', CurrentBoomboxId)
    cb('ok')
end)

RegisterNUICallback('setVolume', function(data, cb)
    if not CurrentBoomboxId then cb('error') return end
    TriggerServerEvent('7h-boombox:server:setVolume', CurrentBoomboxId, tonumber(data.volume) or 0.5)
    cb('ok')
end)

RegisterNUICallback('setEq', function(data, cb)
    if not CurrentBoomboxId then cb('error') return end
    TriggerServerEvent('7h-boombox:server:setEq', CurrentBoomboxId, data.eq, data.megaBass)
    cb('ok')
end)

RegisterNUICallback('setRgb', function(data, cb)
    if not CurrentBoomboxId then cb('error') return end
    TriggerServerEvent('7h-boombox:server:setRgb', CurrentBoomboxId, data.mode, data.color)
    cb('ok')
end)

RegisterNUICallback('burnTape', function(data, cb)
    TriggerServerEvent('7h-boombox:server:burnMixtape', {
        label = data.label,
        url = data.url,
        genre = data.genre
    })
    cb('ok')
end)

RegisterNUICallback('ejectTape', function(_, cb)
    if not CurrentBoomboxId then cb('error') return end
    TriggerServerEvent('7h-boombox:server:ejectTape', CurrentBoomboxId)
    cb('ok')
end)

RegisterNUICallback('onBassDrop', function(data, cb)
    local intensity = tonumber(data.intensity) or 0.2
    TriggerEvent('7h-boombox:client:handleBassDrop', data.id, intensity)
    cb('ok')
end)

-- Initial Client Ready Sync
CreateThread(function()
    Wait(1500)
    TriggerServerEvent('7h-boombox:server:requestSync')
end)
