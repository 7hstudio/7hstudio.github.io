-- =========================================================================
-- 🚗 7H BEATSTORM 3D • VEHICLE PARTY TRUNK DOCK & LIGHT PULSER
-- =========================================================================

local dockedBoomboxProps = {}

-- Check if Vehicle is Valid for Audio Trunk Dock
local function IsValidTrunkVehicle(veh)
    if not DoesEntityExist(veh) then return false end
    local vClass = GetVehicleClass(veh)

    for _, allowed in ipairs(Config.VehicleTrunk.AllowedClasses) do
        if vClass == allowed then return true end
    end
    return false
end

-- Dock Boombox into Vehicle Trunk
function DockBoomboxInTrunk(boomboxId, veh)
    if not IsValidTrunkVehicle(veh) then
        Bridge.Notify(_L('invalid_vehicle'), 'error')
        return false
    end

    -- Check if trunk/boot door is open
    local trunkDoorAngle = GetVehicleDoorAngleRatio(veh, 5)
    if trunkDoorAngle < 0.15 then
        Bridge.Notify(_L('trunk_not_open'), 'error')
        return false
    end

    local vehNetId = VehToNet(veh)
    local ped = PlayerPedId()

    -- Play interaction anim
    local animDict = 'anim@heists@fleeca_bank@drilling'
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Wait(10) end
    TaskPlayAnim(ped, animDict, 'drill_straight_idle', 8.0, -8.0, 1500, 49, 0, false, false, false)
    Wait(1200)

    -- Trigger Server Docking
    TriggerServerEvent('7h-boombox:server:dockInTrunk', boomboxId, vehNetId)
    Bridge.Notify(_L('trunk_docked'), 'success')
    return true
end

exports('DockBoomboxInTrunk', DockBoomboxInTrunk)

-- Undock Boombox from Vehicle Trunk
function UndockBoomboxFromTrunk(boomboxId)
    local bData = ActiveBoomboxes[boomboxId]
    if not bData or not bData.isDocked then return end

    local ped = PlayerPedId()
    local animDict = 'anim@mp_snowball'
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Wait(10) end
    TaskPlayAnim(ped, animDict, 'pickup_snowball', 8.0, -8.0, 1200, 49, 0, false, false, false)
    Wait(900)

    TriggerServerEvent('7h-boombox:server:undockFromTrunk', boomboxId)
    Bridge.Notify(_L('trunk_undocked'), 'primary')
end

-- Client Sync: Attach Model to Vehicle Trunk
RegisterNetEvent('7h-boombox:client:syncTrunkAttachment', function(boomboxId, vehNetId, isDocked)
    if not NetworkDoesNetworkIdExist(vehNetId) then return end
    local veh = NetToVeh(vehNetId)
    if not DoesEntityExist(veh) then return end

    if isDocked then
        -- Clean up existing entity if any
        if dockedBoomboxProps[boomboxId] and DoesEntityExist(dockedBoomboxProps[boomboxId]) then
            DeleteEntity(dockedBoomboxProps[boomboxId])
        end

        local model = Config.Props.DefaultModel
        RequestModel(model)
        while not HasModelLoaded(model) do Wait(10) end

        local trunkBone = -1
        for _, boneName in ipairs(Config.VehicleTrunk.TrunkBones) do
            local idx = GetEntityBoneIndexByName(veh, boneName)
            if idx ~= -1 then
                trunkBone = idx
                break
            end
        end

        local prop = CreateObject(model, 0.0, 0.0, 0.0, false, false, false)
        SetEntityCollision(prop, false, false)

        if trunkBone ~= -1 then
            AttachEntityToEntity(
                prop, veh, trunkBone,
                0.0, -0.15, 0.12,
                0.0, 0.0, 180.0,
                true, true, false, false, 2, true
            )
        else
            local offset = Config.VehicleTrunk.DefaultMountOffset
            local rot = Config.VehicleTrunk.DefaultMountRot
            AttachEntityToEntity(
                prop, veh, 0,
                offset.x, offset.y, offset.z,
                rot.x, rot.y, rot.z,
                true, true, false, false, 2, true
            )
        end

        dockedBoomboxProps[boomboxId] = prop
        if ActiveBoomboxes[boomboxId] then
            ActiveBoomboxes[boomboxId].entity = prop
        end
    else
        if dockedBoomboxProps[boomboxId] and DoesEntityExist(dockedBoomboxProps[boomboxId]) then
            DeleteEntity(dockedBoomboxProps[boomboxId])
            dockedBoomboxProps[boomboxId] = nil
        end
    end
end)

-- Bass-Drop Synchronized Vehicle Lighting Pulser
RegisterNetEvent('7h-boombox:client:pulseTrunkLights', function(vehNetId, intensity)
    if not Config.VehicleTrunk.SyncLightsWithBass then return end
    if not NetworkDoesNetworkIdExist(vehNetId) then return end

    local veh = NetToVeh(vehNetId)
    if not DoesEntityExist(veh) then return end

    CreateThread(function()
        -- Pulse brake and reverse lights with the sub-bass
        SetVehicleBrakeLights(veh, true)

        -- If vehicle has neons enabled, strobe neon intensity
        local hasNeons = IsVehicleNeonLightEnabled(veh, 0) or IsVehicleNeonLightEnabled(veh, 1)
        if hasNeons then
            -- Temporarily flicker neons for bass thump
            SetVehicleNeonLightsColour(veh, 139, 92, 246) -- Neon purple pulse
        end

        Wait(140)
        SetVehicleBrakeLights(veh, false)
    end)
end)
