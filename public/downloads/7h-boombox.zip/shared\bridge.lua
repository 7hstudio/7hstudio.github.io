Bridge = {}
Bridge.Framework = nil
Bridge.Target = nil
Bridge.Inventory = nil

local isServer = IsDuplicityVersion()

-- =========================================================================
-- 1. FRAMEWORK DETECTION & INITIALIZATION
-- =========================================================================
local function DetectFramework()
    if Config.Framework ~= 'auto' then
        Bridge.Framework = Config.Framework
        return
    end

    if GetResourceState('qbx_core') == 'started' then
        Bridge.Framework = 'qbx_core'
    elseif GetResourceState('qb-core') == 'started' then
        Bridge.Framework = 'qb-core'
    else
        Bridge.Framework = 'standalone'
    end
end

DetectFramework()

-- Initialize Framework Object
local QBCore = nil
if Bridge.Framework == 'qb-core' or Bridge.Framework == 'qbx_core' then
    if GetResourceState('qb-core') == 'started' then
        QBCore = exports['qb-core']:GetCoreObject()
    end
end

-- =========================================================================
-- 2. TARGET SYSTEM DETECTION
-- =========================================================================
local function DetectTarget()
    if Config.TargetSystem ~= 'auto' then
        Bridge.Target = Config.TargetSystem
        return
    end

    if GetResourceState('ox_target') == 'started' then
        Bridge.Target = 'ox_target'
    elseif GetResourceState('qb-target') == 'started' then
        Bridge.Target = 'qb-target'
    else
        Bridge.Target = 'none'
    end
end

DetectTarget()

-- =========================================================================
-- 3. INVENTORY SYSTEM DETECTION
-- =========================================================================
local function DetectInventory()
    if Config.Inventory ~= 'auto' then
        Bridge.Inventory = Config.Inventory
        return
    end

    if GetResourceState('ox_inventory') == 'started' then
        Bridge.Inventory = 'ox_inventory'
    elseif GetResourceState('qb-inventory') == 'started' then
        Bridge.Inventory = 'qb-inventory'
    else
        Bridge.Inventory = 'default'
    end
end

DetectInventory()

-- =========================================================================
-- 4. UNIFIED SHARED / SERVER APIS
-- =========================================================================
if isServer then
    function Bridge.GetPlayer(source)
        if Bridge.Framework == 'qbx_core' and exports.qbx_core then
            return exports.qbx_core:GetPlayer(source)
        elseif QBCore then
            return QBCore.Functions.GetPlayer(source)
        end
        return nil
    end

    function Bridge.GetCitizenId(source)
        local player = Bridge.GetPlayer(source)
        if not player then return tostring(source) end
        if player.PlayerData and player.PlayerData.citizenid then
            return player.PlayerData.citizenid
        end
        return tostring(source)
    end

    function Bridge.HasItem(source, item, amount)
        amount = amount or 1
        if Bridge.Inventory == 'ox_inventory' and exports.ox_inventory then
            local count = exports.ox_inventory:GetItemCount(source, item)
            return count and count >= amount
        elseif QBCore then
            local player = QBCore.Functions.GetPlayer(source)
            if player then
                local itemData = player.Functions.GetItemByName(item)
                return itemData and itemData.amount >= amount
            end
        end
        return true
    end

    function Bridge.AddItem(source, item, amount, metadata)
        amount = amount or 1
        if Bridge.Inventory == 'ox_inventory' and exports.ox_inventory then
            return exports.ox_inventory:AddItem(source, item, amount, metadata)
        elseif QBCore then
            local player = QBCore.Functions.GetPlayer(source)
            if player then
                return player.Functions.AddItem(item, amount, nil, metadata)
            end
        end
        return false
    end

    function Bridge.RemoveItem(source, item, amount)
        amount = amount or 1
        if Bridge.Inventory == 'ox_inventory' and exports.ox_inventory then
            return exports.ox_inventory:RemoveItem(source, item, amount)
        elseif QBCore then
            local player = QBCore.Functions.GetPlayer(source)
            if player then
                return player.Functions.RemoveItem(item, amount)
            end
        end
        return false
    end

    function Bridge.Notify(source, message, msgType, duration)
        msgType = msgType or 'primary'
        duration = duration or 4500
        if GetResourceState('ox_lib') == 'started' then
            TriggerClientEvent('ox_lib:notify', source, {
                title = '7H BEATSTORM',
                description = message,
                type = msgType == 'error' and 'error' or (msgType == 'success' and 'success' or 'inform'),
                duration = duration
            })
        elseif QBCore then
            TriggerClientEvent('QBCore:Notify', source, message, msgType, duration)
        else
            TriggerClientEvent('chat:addMessage', source, { args = { '^5[7H BOOMBOX]^0', message } })
        end
    end
else
    -- =========================================================================
    -- 5. CLIENT-SIDE BRIDGE HELPERS
    -- =========================================================================
    function Bridge.Notify(message, msgType, duration)
        msgType = msgType or 'primary'
        duration = duration or 4500
        if GetResourceState('ox_lib') == 'started' then
            lib.notify({
                title = '7H BEATSTORM',
                description = message,
                type = msgType == 'error' and 'error' or (msgType == 'success' and 'success' or 'inform'),
                duration = duration
            })
        elseif QBCore then
            QBCore.Functions.Notify(message, msgType, duration)
        else
            BeginTextCommandThefeedPost("STRING")
            AddTextComponentSubstringPlayerName(message)
            EndTextCommandThefeedPostTicker(true, false)
        end
    end

    function Bridge.ProgressBar(name, label, duration, useAnim, animData)
        if GetResourceState('ox_lib') == 'started' then
            return lib.progressBar({
                duration = duration,
                label = label,
                useWhileDead = false,
                canCancel = true,
                anim = animData and {
                    dict = animData.animDict,
                    clip = animData.animClip,
                    flag = animData.flags or 49
                } or nil
            })
        elseif QBCore then
            local success = false
            local p = promise.new()
            QBCore.Functions.Progressbar(name, label, duration, false, true, {
                disableMovement = false,
                disableCarMovement = false,
                disableMouse = false,
                disableCombat = true,
            }, animData and {
                animDict = animData.animDict,
                anim = animData.animClip,
                flags = animData.flags or 49,
            } or {}, {}, {}, function()
                p:resolve(true)
            end, function()
                p:resolve(false)
            end)
            return Citizen.Await(p)
        else
            Wait(duration)
            return true
        end
    end
end
