-- =========================================================================
-- 🔊 7H BEATSTORM 3D • SERVER AUDIO CONTROLLER
-- =========================================================================

-- Play Track
RegisterNetEvent('7h-boombox:server:playTrack', function(boomboxId, trackData)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    if Config.Battery.Enabled and data.battery <= 0 then
        Bridge.Notify(src, _L('battery_dead'), 'error')
        return
    end

    data.audioState = 'playing'
    data.currentTrack = trackData

    TriggerClientEvent('7h-boombox:client:updateState', -1, boomboxId, data)
    TriggerClientEvent('7h-boombox:client:playMechanicalSfx', -1, 'power_on')
end)

-- Pause Track
RegisterNetEvent('7h-boombox:server:pauseTrack', function(boomboxId)
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    data.audioState = 'paused'
    TriggerClientEvent('7h-boombox:client:updateState', -1, boomboxId, data)
end)

-- Resume Track
RegisterNetEvent('7h-boombox:server:resumeTrack', function(boomboxId)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    if Config.Battery.Enabled and data.battery <= 0 then
        Bridge.Notify(src, _L('battery_dead'), 'error')
        return
    end

    data.audioState = 'playing'
    TriggerClientEvent('7h-boombox:client:updateState', -1, boomboxId, data)
end)

-- Set Volume
RegisterNetEvent('7h-boombox:server:setVolume', function(boomboxId, volume)
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    data.volume = math.max(0.0, math.min(1.0, volume))
    TriggerClientEvent('7h-boombox:client:updateState', -1, boomboxId, data)
end)

-- Set Equalizer & MegaBass
RegisterNetEvent('7h-boombox:server:setEq', function(boomboxId, eqData, megaBass)
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    data.eq = eqData or { bass = 0, mid = 0, treble = 0 }
    data.megaBass = megaBass or false

    TriggerClientEvent('7h-boombox:client:updateState', -1, boomboxId, data)
end)

-- Set RGB Aura Mode & Color
RegisterNetEvent('7h-boombox:server:setRgb', function(boomboxId, mode, color)
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    data.rgbMode = mode or 'beat'
    data.rgbColor = color or '#8b5cf6'

    TriggerClientEvent('7h-boombox:client:updateState', -1, boomboxId, data)
end)

-- Eject Physical Cassette Tape
RegisterNetEvent('7h-boombox:server:ejectTape', function(boomboxId)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data or not data.tape then return end

    local tapeData = data.tape
    data.tape = nil
    data.audioState = 'stopped'
    data.currentTrack = nil

    -- Return cassette to player pockets
    Bridge.AddItem(src, Config.Mixtapes.MixtapeItem, 1, tapeData)
    TriggerClientEvent('7h-boombox:client:updateState', -1, boomboxId, data)
    TriggerClientEvent('7h-boombox:client:playMechanicalSfx', src, 'tape_eject')
    Bridge.Notify(src, _L('eject_tape'), 'inform')
end)
