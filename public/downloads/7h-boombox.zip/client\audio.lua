-- =========================================================================
-- 🔊 7H BEATSTORM 3D • SPATIAL AUDIO & OCCLUSION PROCESSOR
-- =========================================================================

local isAudioActive = false

-- Get Camera Direction Vectors for 3D Audio HRTF
local function GetCamForwardVector()
    local rot = GetGameplayCamRot(2)
    local pitch = math.rad(rot.x)
    local yaw = math.rad(rot.z)

    local vx = -math.sin(yaw) * math.cos(pitch)
    local vy = math.cos(yaw) * math.cos(pitch)
    local vz = math.sin(pitch)

    return vx, vy, vz
end

-- Raycast Occlusion Test between Player Camera & Boombox
local function CheckWallOcclusion(camCoords, targetCoords, ignoreEntity)
    if not Config.Audio.WallOcclusion then return false end

    local ray = StartShapeTestLosProbe(
        camCoords.x, camCoords.y, camCoords.z,
        targetCoords.x, targetCoords.y, targetCoords.z,
        1 | 16 | 256, -- World, buildings, vegetation, glass
        ignoreEntity or PlayerPedId(),
        4
    )

    local retval, hit, _, _, _ = GetShapeTestResult(ray)
    return (hit ~= 0)
end

-- Main Audio Spatialization Loop
CreateThread(function()
    while true do
        local sleep = 1000
        local camCoords = GetGameplayCamCoord()
        local forwardX, forwardY, forwardZ = GetCamForwardVector()
        local activeCount = 0

        local spatialBatch = {}

        for id, bData in pairs(ActiveBoomboxes) do
            if bData.audioState == 'playing' then
                activeCount = activeCount + 1

                -- Determine Live Source Coordinates
                local sourceCoords = bData.coords
                local sourceEntity = bData.entity

                if bData.isCarried and bData.carrierServerId then
                    local carrierPlayer = GetPlayerFromServerId(bData.carrierServerId)
                    if carrierPlayer ~= -1 then
                        local carrierPed = GetPlayerPed(carrierPlayer)
                        if DoesEntityExist(carrierPed) then
                            sourceCoords = GetEntityCoords(carrierPed)
                            sourceEntity = carrierPed
                        end
                    end
                elseif bData.isDocked and bData.vehicleNetId then
                    if NetworkDoesNetworkIdExist(bData.vehicleNetId) then
                        local veh = NetToVeh(bData.vehicleNetId)
                        if DoesEntityExist(veh) then
                            local trunkIndex = GetEntityBoneIndexByName(veh, 'boot')
                            if trunkIndex ~= -1 then
                                sourceCoords = GetWorldPositionOfEntityBone(veh, trunkIndex)
                            else
                                sourceCoords = GetEntityCoords(veh)
                            end
                            sourceEntity = veh
                        end
                    end
                elseif sourceEntity and DoesEntityExist(sourceEntity) then
                    sourceCoords = GetEntityCoords(sourceEntity)
                end

                if sourceCoords then
                    local dist = #(camCoords - sourceCoords)
                    local maxDist = bData.megaBass and Config.Audio.MegaBassDistance or Config.Audio.DefaultDistance

                    if dist <= (maxDist + 5.0) then
                        local isOccluded = CheckWallOcclusion(camCoords, sourceCoords, sourceEntity)
                        
                        -- Relative coordinate calculation for web audio panner
                        local relX = sourceCoords.x - camCoords.x
                        local relY = sourceCoords.y - camCoords.y
                        local relZ = sourceCoords.z - camCoords.z

                        table.insert(spatialBatch, {
                            id = id,
                            x = relX,
                            y = relY,
                            z = relZ,
                            distance = dist,
                            maxDistance = maxDist,
                            occluded = isOccluded,
                            cutoffHz = isOccluded and Config.Audio.OcclusionCutoff or 22000
                        })
                    else
                        table.insert(spatialBatch, {
                            id = id,
                            distance = 999.0,
                            muted = true
                        })
                    end
                end
            end
        end

        if #spatialBatch > 0 then
            sleep = Config.Audio.SpatialSyncInterval or 80
            SendNUIMessage({
                action = 'updateSpatialBatch',
                batch = spatialBatch,
                listenerForward = { x = forwardX, y = forwardY, z = forwardZ }
            })
        end

        Wait(sleep)
    end
end)

-- Bass-Drop Screen Vibration & Sub-Bass FX
RegisterNetEvent('7h-boombox:client:handleBassDrop', function(boomboxId, intensity)
    if not Config.Audio.BassDropCamShake then return end

    local bData = ActiveBoomboxes[boomboxId]
    if not bData then return end

    local ped = PlayerPedId()
    local pedCoords = GetEntityCoords(ped)
    local targetCoords = bData.coords

    if bData.isCarried and bData.carrierServerId then
        local p = GetPlayerFromServerId(bData.carrierServerId)
        if p ~= -1 then targetCoords = GetEntityCoords(GetPlayerPed(p)) end
    elseif bData.isDocked and bData.vehicleNetId then
        local veh = NetToVeh(bData.vehicleNetId)
        if DoesEntityExist(veh) then targetCoords = GetEntityCoords(veh) end
    end

    if not targetCoords then return end

    local dist = #(pedCoords - targetCoords)
    if dist < 14.0 then
        -- Scale intensity with proximity
        local proximityMultiplier = (1.0 - (dist / 14.0))
        local shakeForce = intensity * Config.Audio.BassDropIntensity * proximityMultiplier

        if shakeForce > 0.05 then
            ShakeGameplayCam('JOLT_SHAKE', shakeForce)
        end

        -- Trigger vehicle light pulses if docked
        if bData.isDocked and bData.vehicleNetId then
            TriggerEvent('7h-boombox:client:pulseTrunkLights', bData.vehicleNetId, intensity)
        end

        -- Trigger world RGB aura pulse
        TriggerEvent('7h-boombox:client:pulseWorldRgb', boomboxId, intensity)
    end
end)
