// =========================================================================
// 🎧 7H BEATSTORM 3D • ADVANCED WEB AUDIO API & ACOUSTICS ENGINE
// =========================================================================

let audioCtx = null;
let ytPlayer = null;
let ytReady = false;

// Audio Node graph registry for each active boombox
// audioNodes[id] = { source, gainNode, pannerNode, filterNode, bassFilter, midFilter, trebleFilter, analyserNode, dataArray }
const audioNodes = {};
const htmlAudioElements = {};

// Master Audio Context Initializer
function initAudioContext() {
    if (!audioCtx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        audioCtx = new AudioContext();
    }
    if (audioCtx.state === 'suspended') {
        audioCtx.resume();
    }
}

// Initialize YouTube IFrame API
function initYouTube() {
    if (window.YT) return;
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    const firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
}

window.onYouTubeIframeAPIReady = function() {
    ytPlayer = new YT.Player('yt-hidden-player', {
        height: '0',
        width: '0',
        playerVars: {
            playsinline: 1,
            controls: 0,
            disablekb: 1,
            enablejsapi: 1,
            origin: window.location.origin
        },
        events: {
            onReady: () => {
                ytReady = true;
                console.log('[7H Audio Engine] YouTube IFrame API Ready');
            },
            onStateChange: onYouTubeStateChange,
            onError: (e) => console.warn('[7H Audio Engine] YouTube Player Error:', e.data)
        }
    });
};

function onYouTubeStateChange(event) {
    if (event.data === YT.PlayerState.ENDED) {
        // Track ended
        fetch(`https://${GetParentResourceName()}/pauseTrack`, {
            method: 'POST',
            body: JSON.stringify({})
        });
    }
}

// Extract YouTube Video ID from any standard URL
function extractYouTubeId(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
}

// Create or Get Audio Processing Node Graph for a Boombox
function getOrCreateAudioGraph(id) {
    initAudioContext();

    if (!audioNodes[id]) {
        const gainNode = audioCtx.createGain();
        const pannerNode = audioCtx.createPanner();

        // Configure HRTF 3D Panner
        pannerNode.panningModel = 'HRTF';
        pannerNode.distanceModel = 'inverse';
        pannerNode.refDistance = 3.0;
        pannerNode.maxDistance = 50.0;
        pannerNode.rolloffFactor = 1.15;
        pannerNode.coneInnerAngle = 360;

        // Dynamic Wall Occlusion Filter (Lowpass)
        const filterNode = audioCtx.createBiquadFilter();
        filterNode.type = 'lowpass';
        filterNode.frequency.value = 22000; // Open by default
        filterNode.Q.value = 0.7;

        // 3-Band Equalizer Filters
        const bassFilter = audioCtx.createBiquadFilter();
        bassFilter.type = 'lowshelf';
        bassFilter.frequency.value = 100;
        bassFilter.gain.value = 0;

        const midFilter = audioCtx.createBiquadFilter();
        midFilter.type = 'peaking';
        midFilter.frequency.value = 1000;
        midFilter.Q.value = 1.0;
        midFilter.gain.value = 0;

        const trebleFilter = audioCtx.createBiquadFilter();
        trebleFilter.type = 'highshelf';
        trebleFilter.frequency.value = 8000;
        trebleFilter.gain.value = 0;

        // FFT Analyzer for Visualizer & Sub-Bass Drops
        const analyserNode = audioCtx.createAnalyser();
        analyserNode.fftSize = 128;
        analyserNode.smoothingTimeConstant = 0.85;
        const dataArray = new Uint8Array(analyserNode.frequencyBinCount);

        // Connect graph: Source -> Bass -> Mid -> Treble -> Occlusion Filter -> Analyser -> Panner -> Gain -> Master
        bassFilter.connect(midFilter);
        midFilter.connect(trebleFilter);
        trebleFilter.connect(filterNode);
        filterNode.connect(analyserNode);
        analyserNode.connect(pannerNode);
        pannerNode.connect(gainNode);
        gainNode.connect(audioCtx.destination);

        audioNodes[id] = {
            gainNode,
            pannerNode,
            filterNode,
            bassFilter,
            midFilter,
            trebleFilter,
            analyserNode,
            dataArray,
            mediaSource: null,
            lastBassDropTime: 0
        };
    }

    return audioNodes[id];
}

// Play Audio Source
function playBoomboxAudio(boombox) {
    if (!boombox || !boombox.currentTrack || !boombox.currentTrack.url) return;
    initAudioContext();

    const graph = getOrCreateAudioGraph(boombox.id);
    const url = boombox.currentTrack.url;
    const ytId = extractYouTubeId(url);

    // Set initial EQ and volume
    updateBoomboxVolume(boombox.id, boombox.volume);
    updateBoomboxEq(boombox.id, boombox.eq, boombox.megaBass);

    // Stop existing HTML5 audio if any
    if (htmlAudioElements[boombox.id]) {
        htmlAudioElements[boombox.id].pause();
        htmlAudioElements[boombox.id].src = '';
    }

    if (ytId && ytReady && ytPlayer) {
        // YouTube Stream
        ytPlayer.loadVideoById(ytId);
        ytPlayer.setVolume(Math.round(boombox.volume * 100));
        ytPlayer.playVideo();
    } else {
        // Direct MP3, Radio Stream, or SoundCloud
        const audio = new Audio();
        audio.crossOrigin = 'anonymous';
        audio.src = url;

        try {
            if (!graph.mediaSource) {
                const source = audioCtx.createMediaElementSource(audio);
                source.connect(graph.bassFilter);
                graph.mediaSource = source;
            }
        } catch(e) {}

        audio.play().catch(err => console.warn('[7H Audio] HTML5 Play Error:', err));
        htmlAudioElements[boombox.id] = audio;
    }
}

// Pause Audio
function pauseBoomboxAudio(id) {
    if (ytPlayer && ytReady) {
        try { ytPlayer.pauseVideo(); } catch(e) {}
    }
    if (htmlAudioElements[id]) {
        htmlAudioElements[id].pause();
    }
}

// Resume Audio
function resumeBoomboxAudio(id) {
    initAudioContext();
    if (ytPlayer && ytReady) {
        try { ytPlayer.playVideo(); } catch(e) {}
    }
    if (htmlAudioElements[id]) {
        htmlAudioElements[id].play().catch(() => {});
    }
}

// Stop Audio
function stopBoomboxAudio(id) {
    if (ytPlayer && ytReady) {
        try { ytPlayer.stopVideo(); } catch(e) {}
    }
    if (htmlAudioElements[id]) {
        htmlAudioElements[id].pause();
        htmlAudioElements[id].src = '';
        delete htmlAudioElements[id];
    }
}

// Update 3D Panner & Occlusion Filter from Lua Client Batch
function updateSpatialBatch(batch, forward) {
    if (!audioCtx) return;

    // Update Listener Orientation if supported
    if (audioCtx.listener.forwardX && forward) {
        audioCtx.listener.forwardX.setValueAtTime(forward.x, audioCtx.currentTime);
        audioCtx.listener.forwardY.setValueAtTime(forward.y, audioCtx.currentTime);
        audioCtx.listener.forwardZ.setValueAtTime(forward.z, audioCtx.currentTime);
    }

    for (let i = 0; i < batch.length; i++) {
        const item = batch[i];
        const graph = audioNodes[item.id];
        if (!graph) continue;

        if (item.muted) {
            graph.gainNode.gain.setValueAtTime(0.0001, audioCtx.currentTime);
            continue;
        }

        // Relative spatial positioning
        if (graph.pannerNode.positionX) {
            graph.pannerNode.positionX.setValueAtTime(item.x, audioCtx.currentTime);
            graph.pannerNode.positionY.setValueAtTime(item.y, audioCtx.currentTime);
            graph.pannerNode.positionZ.setValueAtTime(item.z, audioCtx.currentTime);
        } else {
            graph.pannerNode.setPosition(item.x, item.y, item.z);
        }

        // Smooth Occlusion Lowpass Filtering
        const targetFreq = item.cutoffHz || (item.occluded ? 380 : 22000);
        graph.filterNode.frequency.setTargetAtTime(targetFreq, audioCtx.currentTime, 0.12);

        // Distance attenuation
        const distRatio = Math.max(0, 1.0 - (item.distance / item.maxDistance));
        const effectiveVol = distRatio * (graph.masterVol || 0.6);
        graph.gainNode.gain.setTargetAtTime(effectiveVol, audioCtx.currentTime, 0.05);

        // Check Sub-Bass Frequency (Bass-Drop Detector)
        detectBassDrop(item.id, graph);
    }
}

// Equalizer & MegaBass Updates
function updateBoomboxEq(id, eq, megaBass) {
    const graph = audioNodes[id];
    if (!graph || !audioCtx) return;

    const bassVal = (eq && eq.bass) ? Number(eq.bass) : 0;
    const midVal = (eq && eq.mid) ? Number(eq.mid) : 0;
    const trebVal = (eq && eq.treble) ? Number(eq.treble) : 0;

    // MegaBass adds +12dB low-end punch at 60Hz
    const megaBassBoost = megaBass ? 12 : 0;

    graph.bassFilter.gain.setTargetAtTime(bassVal + megaBassBoost, audioCtx.currentTime, 0.1);
    graph.midFilter.gain.setTargetAtTime(midVal, audioCtx.currentTime, 0.1);
    graph.trebleFilter.gain.setTargetAtTime(trebVal, audioCtx.currentTime, 0.1);
}

// Volume Update
function updateBoomboxVolume(id, volume) {
    const graph = audioNodes[id];
    if (!graph) return;
    graph.masterVol = Number(volume);
    if (ytPlayer && ytReady) {
        try { ytPlayer.setVolume(Math.round(volume * 100)); } catch(e) {}
    }
}

// Sub-Bass 808 Drop Analyzer
function detectBassDrop(id, graph) {
    if (!graph.analyserNode) return;
    graph.analyserNode.getByteFrequencyData(graph.dataArray);

    // Sum first 3 low-frequency bins (approx. 20Hz - 90Hz)
    const subBassEnergy = (graph.dataArray[0] + graph.dataArray[1] + graph.dataArray[2]) / 3;

    // Threshold check for bass drop
    const now = Date.now();
    if (subBassEnergy > 210 && (now - graph.lastBassDropTime) > 400) {
        graph.lastBassDropTime = now;
        const normalizedIntensity = (subBassEnergy - 200) / 55; // 0.1 to 1.0

        // Send to FiveM Client for Camera Vibration & Vehicle Strobe
        fetch(`https://${GetParentResourceName()}/onBassDrop`, {
            method: 'POST',
            body: JSON.stringify({
                id: id,
                intensity: normalizedIntensity
            })
        }).catch(() => {});
    }
}

// Synthesize Mechanical Sound Effects
function playSynthesizedSfx(type) {
    initAudioContext();
    const now = audioCtx.currentTime;

    if (type === 'tape_insert' || type === 'click') {
        // Crisp mechanical dual-click
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(450, now);
        osc.frequency.exponentialRampToValueAtTime(80, now + 0.08);

        gain.gain.setValueAtTime(0.35, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.08);

    } else if (type === 'tape_eject') {
        // Spring eject click
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(280, now);
        osc.frequency.exponentialRampToValueAtTime(50, now + 0.12);

        gain.gain.setValueAtTime(0.4, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.12);

    } else if (type === 'power_on') {
        // Cyberpunk power startup chime
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.28);

        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
    }
}

// Init YouTube API on page load
initYouTube();
