# ⚡ 7H BEATSTORM 3D • INSTALLATION & DOCUMENTATION

Bienvenue sur le guide officiel d'installation de **7H BeatStorm 3D**, le système de Boombox le plus avancé et immersif de l'histoire de FiveM.

---

## 📦 1. AJOUT DES ITEMS DANS VOTRE INVENTAIRE

### A. Pour `ox_inventory` (`ox_inventory/data/items.lua`) :
```lua
['boombox'] = {
    label = '7H PartyBox Pro',
    weight = 4500,
    stack = false,
    close = true,
    description = 'Boombox 3D haute fidélité avec égaliseur de studio et dock de coffre.',
    client = {
        image = 'boombox.png',
    }
},

['blank_cassette'] = {
    label = 'Cassette Vierge',
    weight = 120,
    stack = true,
    close = true,
    description = 'Une cassette audio vierge prête à enregistrer un morceau ou une playlist.',
    client = {
        image = 'blank_cassette.png',
    }
},

['boombox_tape'] = {
    label = 'Mixtape Enregistrée',
    weight = 120,
    stack = false,
    close = true,
    description = 'Une cassette audio physique gravée avec un titre personnalisé.',
    client = {
        image = 'boombox_tape.png',
    }
},

['powerbank'] = {
    label = 'Powerbank 20000mAh',
    weight = 600,
    stack = true,
    close = true,
    description = 'Batterie externe haute capacité pour recharger la boombox sur le terrain.',
    client = {
        image = 'powerbank.png',
    }
},
```

---

### B. Pour `qb-core` (`qb-core/shared/items.lua`) :
```lua
['boombox'] = {
    name = 'boombox',
    label = '7H PartyBox Pro',
    weight = 4500,
    type = 'item',
    image = 'boombox.png',
    unique = true,
    useable = true,
    shouldClose = true,
    combinable = nil,
    description = 'Boombox 3D haute fidélité avec égaliseur de studio et dock de coffre.'
},

['blank_cassette'] = {
    name = 'blank_cassette',
    label = 'Cassette Vierge',
    weight = 120,
    type = 'item',
    image = 'blank_cassette.png',
    unique = false,
    useable = true,
    shouldClose = true,
    combinable = nil,
    description = 'Une cassette audio vierge prête à enregistrer un morceau.'
},

['boombox_tape'] = {
    name = 'boombox_tape',
    label = 'Mixtape Enregistrée',
    weight = 120,
    type = 'item',
    image = 'boombox_tape.png',
    unique = true,
    useable = true,
    shouldClose = true,
    combinable = nil,
    description = 'Une cassette audio physique gravée avec un titre personnalisé.'
},

['powerbank'] = {
    name = 'powerbank',
    label = 'Powerbank 20000mAh',
    weight = 600,
    type = 'item',
    image = 'powerbank.png',
    unique = false,
    useable = true,
    shouldClose = true,
    combinable = nil,
    description = 'Batterie externe haute capacité pour recharger la boombox.'
},
```

---

## 🚀 2. ACTIVATION DANS `server.cfg`

Placez le dossier `7h-boombox` dans votre dossier `resources/[7h]/` ou `resources/`, puis ajoutez la ligne suivante dans votre fichier `server.cfg` :

```cfg
ensure ox_lib
ensure 7h-boombox
```

---

## 🌟 3. FONCTIONNALITÉS EXCLUSIVES (VIRAL FEATURES)

1. **Gizmo de Placement Raycast** :
   - Prévisualisation holographique de la boombox avec détection du sol et collision.
   - Molette de la souris / Flèches pour pivoter la boombox à 360° avant de la poser.

2. **Système de Port Multistyle & Transfert d'Ami** :
   - Porte sur l'épaule style Streetwear / Hip-Hop.
   - Porte à la main style valise.
   - Possibilité de passer directement la boombox à un ami via une animation de handoff synchronisée.

3. **Moteur Acoustique 3D & Occlusion Murale Réelle** :
   - Si un joueur rentre dans un bâtiment ou ferme une porte, le son s'étouffe instantanément grâce au filtre passe-bas temps réel (Muffled Party Sound).

4. **Party Trunk Mode (Dock de Coffre de Voiture)** :
   - Ouvrez le coffre d'un véhicule et installez la boombox directement dedans.
   - Les feux de stop et les néons du véhicule pulsent en rythme avec le Sub-Bass de la musique !

5. **Cassettes Physiques (Mixtapes)** :
   - Gravez des cassettes vierges avec n'importe quel lien YouTube ou MP3.
   - Écrivez le nom au marqueur sur la cassette.
   - Insérez et éjectez la cassette avec de vrais sons mécaniques de clic et de moteur.

6. **Secousse Caméra Bass Drop** :
   - Lorsqu'un kick 808 percutant tombe, l'écran des joueurs à proximité vibre subtilement.

7. **Batterie Réelle & Éclairage RGB** :
   - La batterie se décharge avec le volume et le MegaBass.
   - Rechargement via Powerbank ou en roulant avec la boombox dans le coffre.
   - Anneau de lumière 3D dans le jeu (Mode Beat, Rainbow, Statique ou Off).

---

## 🛠️ 4. EXPORTS DISPONIBLES (POUR LES DÉVELOPPEURS)

```lua
-- Ouvrir l'interface d'une boombox
exports['7h-boombox']:OpenBoomboxUI(boomboxId)

-- Vérifier si le joueur local porte une boombox
local isCarrying = exports['7h-boombox']:IsCarryingBoombox()

-- Récupérer l'ID de la boombox active
local activeId = exports['7h-boombox']:GetActiveBoombox()

-- Installer dans le coffre d'un véhicule
exports['7h-boombox']:DockBoomboxInTrunk(boomboxId, vehicleEntity)
```
