-- =========================================================================
-- 🌈 7H BEATSTORM 3D • WORLD RGB AURA & LIGHT PULSER
-- =========================================================================

local activeWorldPulses = {}

-- Helper to convert Hex to RGB
local function HexToRgb(hex)
    hex = hex:gsub('#', '')
    if #hex == 3 then
        hex = hex:sub(1,1):rep(2) .. hex:sub(2,2):rep(2) .. hex:sub(3,3):rep(2)
    end
    local r = tonumber(hex:sub(1,2), 16) or 139
    local g = tonumber(hex:sub(3,4), 16) or 92
    local b = tonumber(hex:sub(5,6), 16) or 246
    return r, g, b
end

-- World RGB Light Emission Thread
CreateThread(function()
    local rainbowHue = 0.0

    while true do
        local sleep = 1000
        local camCoords = GetGameplayCamCoord()
        local hasActiveLight = false

        for id, bData in pairs(ActiveBoomboxes) do
            if bData.audioState == 'playing' and bData.rgbMode ~= 'off' then
                local coords = bData.coords

                if bData.isCarried and bData.carrierServerId then
                    local p = GetPlayerFromServerId(bData.carrierServerId)
                    if p ~= -1 then coords = GetEntityCoords(GetPlayerPed(p)) end
                elseif bData.isDocked and bData.vehicleNetId then
                    local veh = NetToVeh(bData.vehicleNetId)
                    if DoesEntityExist(veh) then coords = GetEntityCoords(veh) end
                elseif bData.entity and DoesEntityExist(bData.entity) then
                    coords = GetEntityCoords(bData.entity)
                end

                if coords then
                    local dist = #(camCoords - coords)
                    if dist <= 25.0 then
                        hasActiveLight = true
                        sleep = 0

                        local r, g, b = 139, 92, 246
                        local intensity = Config.RGBLights.Intensity or 2.2
                        local radius = Config.RGBLights.Radius or 4.5

                        -- Mode: Rainbow Cycle
                        if bData.rgbMode == 'rainbow' then
                            rainbowHue = (rainbowHue + 0.01) % 1.0
                            local h = rainbowHue * 6.0
                            local c = 1.0
                            local x = c * (1.0 - math.abs((h % 2.0) - 1.0))
                            local r1, g1, b1 = 0, 0, 0
                            if h < 1 then r1, g1, b1 = c, x, 0
                            elseif h < 2 then r1, g1, b1 = x, c, 0
                            elseif h < 3 then r1, g1, b1 = 0, c, x
                            elseif h < 4 then r1, g1, b1 = 0, x, c
                            elseif h < 5 then r1, g1, b1 = x, 0, c
                            else r1, g1, b1 = c, 0, x end
                            r, g, b = math.floor(r1 * 255), math.floor(g1 * 255), math.floor(b1 * 255)

                        -- Mode: Static Color
                        elseif bData.rgbMode == 'static' and bData.rgbColor then
                            r, g, b = HexToRgb(bData.rgbColor)

                        -- Mode: Beat Pulse
                        elseif bData.rgbMode == 'beat' then
                            if bData.rgbColor then
                                r, g, b = HexToRgb(bData.rgbColor)
                            end
                            local pulseBoost = activeWorldPulses[id] or 0.0
                            intensity = intensity + (pulseBoost * 2.8)
                            radius = radius + (pulseBoost * 1.5)
                        end

                        DrawLightWithRange(
                            coords.x, coords.y, coords.z + 0.35,
                            r, g, b,
                            radius,
                            intensity
                        )
                    end
                end
            end
        end

        Wait(sleep)
    end
end)

-- Temporary Bass Boost Decay Loop
CreateThread(function()
    while true do
        local sleep = 500
        for id, boost in pairs(activeWorldPulses) do
            if boost > 0.0 then
                sleep = 50
                activeWorldPulses[id] = math.max(0.0, boost - 0.15)
            else
                activeWorldPulses[id] = nil
            end
        end
        Wait(sleep)
    end
end)

RegisterNetEvent('7h-boombox:client:pulseWorldRgb', function(boomboxId, intensity)
    activeWorldPulses[boomboxId] = math.min(1.5, (activeWorldPulses[boomboxId] or 0.0) + (intensity * 0.8))
end)
