-- =========================================================================
-- ⚡ 7H BEATSTORM 3D • SERVER MAIN CONTROLLER
-- =========================================================================

ServerBoomboxes = {}
local boomboxCounter = 0

local function GenerateBoomboxId()
    boomboxCounter = boomboxCounter + 1
    return boomboxCounter
end

-- Broadcast State to All Clients
local function BroadcastBoomboxState(id)
    local data = ServerBoomboxes[id]
    if data then
        TriggerClientEvent('7h-boombox:client:updateState', -1, id, data)
    end
end

-- =========================================================================
-- SYNC & CONNECTIVITY HANDLERS
-- =========================================================================
RegisterNetEvent('7h-boombox:server:requestSync', function()
    local src = source
    TriggerClientEvent('7h-boombox:client:syncAll', src, ServerBoomboxes)
end)

-- Place Boombox in the World
RegisterNetEvent('7h-boombox:server:placeBoombox', function(coords, heading, itemMetadata)
    local src = source
    local citizenId = Bridge.GetCitizenId(src)

    -- If this is an existing boombox being dropped from hands
    local existingId = itemMetadata and itemMetadata.id
    local bId = existingId or GenerateBoomboxId()

    local initialBattery = (itemMetadata and itemMetadata.battery) or 100
    local existingTape = (itemMetadata and itemMetadata.tape) or nil

    ServerBoomboxes[bId] = {
        id = bId,
        ownerCitizenId = citizenId,
        coords = coords,
        heading = heading or 0.0,
        isCarried = false,
        carrierServerId = nil,
        carrierStance = nil,
        isDocked = false,
        vehicleNetId = nil,
        audioState = 'stopped',
        currentTrack = nil,
        volume = Config.Audio.DefaultVolume,
        megaBass = false,
        eq = { bass = 0, mid = 0, treble = 0 },
        battery = initialBattery,
        rgbMode = Config.RGBLights.DefaultMode,
        rgbColor = '#8b5cf6',
        tape = existingTape
    }

    -- Remove item from player inventory if this was newly placed from pocket
    if not existingId then
        Bridge.RemoveItem(src, 'boombox', 1)
    end

    TriggerClientEvent('7h-boombox:client:playMechanicalSfx', src, 'click')
    BroadcastBoomboxState(bId)
end)

-- Pick Up Boombox back into Inventory
RegisterNetEvent('7h-boombox:server:pickupBoombox', function(boomboxId)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    -- Prepare item metadata to preserve battery & inserted cassette
    local metadata = {
        battery = data.battery,
        tape = data.tape,
        description = string.format("Batterie: %d%% | Cassette: %s", data.battery, (data.tape and data.tape.label or "Aucune"))
    }

    -- Add item to inventory
    local success = Bridge.AddItem(src, 'boombox', 1, metadata)
    if success then
        ServerBoomboxes[boomboxId] = nil
        TriggerClientEvent('7h-boombox:client:remove', -1, boomboxId)
        TriggerClientEvent('7h-boombox:client:playMechanicalSfx', src, 'click')
    else
        Bridge.Notify(src, 'Inventaire plein !', 'error')
    end
end)

-- Set Carrying State
RegisterNetEvent('7h-boombox:server:setCarried', function(boomboxId, isCarried, stance)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    data.isCarried = isCarried
    data.carrierServerId = isCarried and src or nil
    data.carrierStance = stance or 'shoulder'
    data.isDocked = false
    data.vehicleNetId = nil

    BroadcastBoomboxState(boomboxId)
end)

-- Transfer Carrier to Friend
RegisterNetEvent('7h-boombox:server:transferCarrier', function(boomboxId, targetServerId)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    data.isCarried = true
    data.carrierServerId = targetServerId
    data.isDocked = false
    data.vehicleNetId = nil

    BroadcastBoomboxState(boomboxId)
    TriggerClientEvent('7h-boombox:client:receiveBoomboxHandoff', targetServerId, boomboxId, data.carrierStance)
end)

-- Dock in Vehicle Trunk
RegisterNetEvent('7h-boombox:server:dockInTrunk', function(boomboxId, vehNetId)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    data.isCarried = false
    data.carrierServerId = nil
    data.isDocked = true
    data.vehicleNetId = vehNetId

    BroadcastBoomboxState(boomboxId)
    TriggerClientEvent('7h-boombox:client:syncTrunkAttachment', -1, boomboxId, vehNetId, true)
end)

-- Undock from Vehicle Trunk
RegisterNetEvent('7h-boombox:server:undockFromTrunk', function(boomboxId)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data or not data.isDocked then return end

    local vehNetId = data.vehicleNetId
    data.isDocked = false
    data.vehicleNetId = nil
    data.isCarried = true
    data.carrierServerId = src

    BroadcastBoomboxState(boomboxId)
    TriggerClientEvent('7h-boombox:client:syncTrunkAttachment', -1, boomboxId, vehNetId, false)
    TriggerClientEvent('7h-boombox:client:carryStance', src, boomboxId, 'shoulder')
end)

-- Recharge Battery with Powerbank
RegisterNetEvent('7h-boombox:server:rechargeBattery', function(boomboxId)
    local src = source
    local data = ServerBoomboxes[boomboxId]
    if not data then return end

    local item = Config.Battery.RechargeItem or 'powerbank'
    if Bridge.HasItem(src, item, 1) then
        Bridge.RemoveItem(src, item, 1)

        data.battery = math.min(100, data.battery + (Config.Battery.RechargeAmount or 50))
        BroadcastBoomboxState(boomboxId)

        TriggerClientEvent('7h-boombox:client:playMechanicalSfx', src, 'power_on')
        Bridge.Notify(src, _L('battery_charged'), 'success')
    else
        Bridge.Notify(src, _L('no_powerbank'), 'error')
    end
end)

-- =========================================================================
-- BATTERY DEGRADATION & RUNTIME ENGINE
-- =========================================================================
CreateThread(function()
    while true do
        Wait(Config.Battery.BaseDrainInterval * 1000)

        if Config.Battery.Enabled then
            for id, bData in pairs(ServerBoomboxes) do
                if bData.audioState == 'playing' then
                    -- Battery Drain Rate calculation
                    local drain = 1
                    if bData.volume > 0.85 or bData.megaBass then
                        drain = math.floor(1 * Config.Battery.HighVolumeDrainMultiplier)
                    end

                    bData.battery = math.max(0, bData.battery - drain)

                    -- Low battery audio cue
                    if bData.battery == Config.Battery.LowBatteryWarning and bData.carrierServerId then
                        Bridge.Notify(bData.carrierServerId, _L('low_battery_warn'), 'error')
                    end

                    -- Battery dead: cut audio
                    if bData.battery <= 0 then
                        bData.audioState = 'stopped'
                        bData.currentTrack = nil
                        if bData.carrierServerId then
                            Bridge.Notify(bData.carrierServerId, _L('battery_dead'), 'error')
                        end
                        TriggerClientEvent('7h-boombox:client:playMechanicalSfx', -1, 'tape_eject')
                    end

                    BroadcastBoomboxState(id)
                end
            end
        end
    end
end)

-- Cleanup on Player Dropped
AddEventHandler('playerDropped', function()
    local src = source
    for id, bData in pairs(ServerBoomboxes) do
        if bData.carrierServerId == src then
            -- Drop boombox at player's last location
            bData.isCarried = false
            bData.carrierServerId = nil
            bData.carrierStance = nil
            BroadcastBoomboxState(id)
        end
    end
end)
